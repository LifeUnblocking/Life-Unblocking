import firebase from "firebase";

const firebaseApp = firebase.initializeApp({
  apiKey: "AIzaSyCWsbQXru-cezQm_3OFyLdgc25wcYXpTUg",
  authDomain: "life-unblocking.firebaseapp.com",
  projectId: "life-unblocking",
  storageBucket: "life-unblocking.appspot.com",
  messagingSenderId: "247712367604",
  appId: "1:247712367604:web:80e3382039d3b798762fa1",
  measurementId: "G-S76KT6XH0R"
});
const db = firebaseApp.firestore();
const storeage = firebaseApp.storage();
const auth = firebaseApp.auth();

export {
  db,
  storeage,
  auth
};