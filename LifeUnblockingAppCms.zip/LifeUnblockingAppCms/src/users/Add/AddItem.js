import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheckSquare, faCoffee, faPlus, faMinusSquare } from '@fortawesome/free-solid-svg-icons'
import { Link } from "react-router-dom";
import { db, storeage } from '../../firebase';
import setting from '../setting.json'; // setting[0].collection
import firebase from 'firebase';
import './AddItem.css'
import defoultAvader from '../../images/avatar-placeholder.webp'

function AddItem() {

    const [Name, setName] = useState("");
    const [Email, setEmail] = useState("");
    const [Phone, setPhone] = useState("");
    const [Addrass, setAddrass] = useState("");
    const [Avader, setAvader] = useState("");
    const [Image, setImage] = useState("");
    const [Progras, setProgras] = useState("")

    const submitFunction = ((e) => {
        if (Name && Email && Phone && Addrass) {

            if (Image) {
                const uploadTask = storeage.ref(`${setting[0].collection}/${Image.name}`).put(Image);
                uploadTask.on(
                    "state_changed",
                    (snapshort) => {
                        const prograss = Math.round((snapshort.bytesTransferred / snapshort.totalBytes) * 100);
                        setProgras(prograss);
                    },
                    (error) => {
                        alert(error.message);
                    },
                    () => {
                        storeage.ref(setting[0].collection).child(Image.name).getDownloadURL().then((url) => {
                            db.collection(setting[0].collection).add({
                                name: Name,
                                email: Email,
                                phone: Phone,
                                addrass: Addrass,
                                img: url,
                                timestamp: firebase.firestore.FieldValue.serverTimestamp(),
                            }).then(() => {
                                alert('user has been added');
                                setName('');
                                setEmail('');
                                setPhone('');
                                setAddrass('');
                            });
                        });
                    }
                );
            } else {
                db.collection(setting[0].collection).add({
                    name: Name,
                    email: Email,
                    phone: Phone,
                    addrass: Addrass,
                    timestamp: firebase.firestore.FieldValue.serverTimestamp(),
                }).then(() => {
                    alert('user has been added');
                    setName('');
                    setEmail('');
                    setPhone('');
                    setAddrass('');
                });
            }


        } else {
            console.log('please seet all the imput');
        }

        e.preventDefault();
    });


    //previw images
    const selectedFile = ((e) => {
        var file = document.getElementById('avader').files[0];
        setAvader(window.URL.createObjectURL(file));
        setImage(file);
    });

    return (
        <div className="AddItem">
            <form onSubmit={submitFunction} >
                {/* header */}
                <div className="header">
                    <h1>Add {setting[0].collection}</h1>
                    <Link to={`/${setting[0].collection}`}><FontAwesomeIcon icon={faMinusSquare} color="red" size="2x" /></Link>
                </div>

                {/* avader */}
                <div onClick={() => { document.getElementById('avader').click() }} className="avader" style={{ backgroundImage: `url(${Avader ? Avader : defoultAvader})` }}>
                <FontAwesomeIcon icon={faPlus} color="#ccc" size="2x" />
                    <input type="file" id="avader" onChange={selectedFile} style={{ display: 'none' }} />
                </div>

                {/* inputs */}
                <input type="text" onChange={(e) => (setName(e.target.value))} value={Name} placeholder="Name" />
                <input type="email" onChange={(e) => { setEmail(e.target.value) }} value={Email} placeholder="email" />
                <input type="number" onChange={(e) => { setPhone(e.target.value) }} value={Phone} placeholder="phone" />
                <textarea onChange={(e) => { setAddrass(e.target.value) }} value={Addrass} placeholder="addrase" cols="30" rows="5"></textarea>
                
                {/* submit */}
                <input type="submit" value={`Add ${setting[0].collection}`} />
                

                {/* prograsse */}
                <progress id="file" value={Progras} max="100"> {`${Progras} %`} </progress>
            </form>
        </div>
    )
}


export default AddItem;