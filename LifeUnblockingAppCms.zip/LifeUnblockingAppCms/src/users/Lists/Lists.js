import React, { useEffect, useState } from 'react';
import { Link, Switch, Route, useRouteMatch } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTrash, faEye, faEdit, faArrowLeft, faArrowRight } from '@fortawesome/free-solid-svg-icons';
import { db } from '../../firebase';
import setting from '../setting.json'; // setting[0].collection
import './Lists.css';
import View from '../View/View';
import Update from '../Update/Update';
import AddItem from '../Add/AddItem';
import defoultAvader from '../../images/avatar-placeholder.webp'



function Lists() {

    let match = useRouteMatch();

    const [List, setList] = useState([]);

    // firebase
    useEffect(() => {
        db.collection(setting[0].collection).orderBy('timestamp', 'desc').onSnapshot(snapshot => {
            const data = snapshot.docs.map(doc => {
                let id = doc.id;
                let data = doc.data();
                return { id, ...data }
            });

            setList(data);
        });
    }, []);
    const remove = (id) => {
        var r = window.confirm(`do you want to delete this ${setting[0].collection}?`);
        if (r == true) {
            db.collection(setting[0].collection).doc(id).delete();
        }
    }


    return (
        <div className="Lists">
            <div className="head">
                <div>
                    <h1>all the {setting[0].collection}</h1>
                    <p>{List.length} {setting[0].collection} found</p>
                </div>
                <div>
                    {/* <Link to={`${match.url}/add-${setting[0].collection}`}><button className="addbutton">add {setting[0].collection}</button></Link> */}
                </div>
            </div>
            <hr />

            <table style={{ width: "100%" }}>
                <thead>
                    <tr>
                        <th>image</th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Email</th>
                        {/* <th>Addrras</th> */}
                    </tr>
                </thead>
                <tbody>
                    {List.map(item => (
                        <tr key={item.id}>
                            <td><img className="avader" src={item.photoURL ? item.photoURL : defoultAvader} alt="" /></td>
                            <td>{item.name}</td>
                            <td>{item.phone}</td>
                            <td>{item.email}</td>
                            {/* <td>{item.address}</td> */}
                            {/* <td><Link to={`${match.url}/view-${setting[0].collection}/${item.id}`}><FontAwesomeIcon icon={faEye} color="#6ac318" size="1x" /></Link></td>
                            <td><Link to={`${match.url}/update-${setting[0].collection}/${item.id}`}><FontAwesomeIcon icon={faEdit} color="#6ac318" size="1x" /></Link></td> */}
                            <td><FontAwesomeIcon onClick={(e) => { remove(item.id) }} icon={faTrash} color="red" size="1x" /></td>
                        </tr>
                    ))}
                </tbody>
            </table>

            {List.length === 0 ? <NoiTemsFound /> : null}


            <Switch>
                {/* ADD USER */}
                <Route path={`${match.url}/add-${setting[0].collection}`} children={<AddItem />} />

                {/* UPDATE USER */}
                <Route path={`${match.url}/update-${setting[0].collection}/:id`} children={<Update />} />

                {/* VIEW USER */}
                <Route path={`${match.url}/view-${setting[0].collection}/:id`} children={<View />} />
            </Switch>
        </div>
    )
}

function NoiTemsFound() {
    return (
        <div className="NoiTemsFound">
            <h1>here no item availe availe</h1>
            <p>add item</p>
        </div>
    );
}

export default Lists


