import React, { useState, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheckSquare, faCoffee, faPlus, faMinusSquare } from '@fortawesome/free-solid-svg-icons'
import { useParams, Link, useHistory } from "react-router-dom";
import { db, storeage } from '../../firebase';
import firebase from 'firebase';
import setting from '../setting.json'; // setting[0].collection
import './Update.css'
import defoultAvader from '../../images/avatar-placeholder.webp'

function Update() {

    // Route paramiter
    const { id } = useParams();
    let history = useHistory();

    //inputs
    const [Name, setName] = useState("");
    const [Email, setEmail] = useState("");
    const [Phone, setPhone] = useState("");
    const [Addrass, setAddrass] = useState("");
    const [Avader, setAvader] = useState("");
    const [Image, setImage] = useState("");
    const [Progras, setProgras] = useState("");

    useEffect(() => {
        db.collection(setting[0].collection).doc(id).get().then((e) => {
            const item = e.data();
            setName(item.name);
            setEmail(item.email);
            setPhone(item.phone);
            setAddrass(item.address);
            setAvader(item.img);
        });
    }, []);

    const submitFunction = ((e) => {

        if (Image) {
            const uploadTask = storeage.ref(`${setting[0].collection}/${Image.name}`).put(Image);
            uploadTask.on(
                "state_changed",
                (snapshort) => {
                    const prograss = Math.round((snapshort.bytesTransferred / snapshort.totalBytes) * 100);
                    setProgras(prograss);
                },
                (error) => {
                    alert(error.message);
                },
                () => {
                    storeage.ref(setting[0].collection).child(Image.name).getDownloadURL().then((url) => {
                        if(Name){
                            db.collection(setting[0].collection).doc(id).update({
                                name: Name,
                            }).then(() => {
                                console.log(`${setting[0].collection} has been update`);
                            });
                        }
                        if(Email){
                            db.collection(setting[0].collection).doc(id).update({
                                email: Email,
                            }).then(() => {
                                console.log(`${setting[0].collection} has been update`);
                            });
                        }
                        if(Addrass){
                            db.collection(setting[0].collection).doc(id).update({
                                address: Addrass,
                            }).then(() => {
                                console.log(`${setting[0].collection} has been update`);
                            });
                        }
                        db.collection(setting[0].collection).doc(id).update({
                            img: url,
                        }).then(() => {
                            alert(`${setting[0].collection} has been update`);
                        });
                    })

                })
        } else {
            if(Name){
                db.collection(setting[0].collection).doc(id).update({
                    name: Name,
                }).then(() => {
                    console.log(`${setting[0].collection} has been update`);
                });
            }
            if(Email){
                db.collection(setting[0].collection).doc(id).update({
                    email: Email,
                }).then(() => {
                    console.log(`${setting[0].collection} has been update`);
                });
            }
            if(Addrass){
                db.collection(setting[0].collection).doc(id).update({
                    address: Addrass,
                }).then(() => {
                    console.log(`${setting[0].collection} has been update`);
                });
            }
            alert(`${setting[0].collection} has been update`);
        }

        e.preventDefault();
    });

    //previw images
    const selectedFile = ((e) => {
        var file = document.getElementById('avader').files[0];
        setAvader(window.URL.createObjectURL(file));
        setImage(file);
    });


    return (
        <div className="Update">
            <form onSubmit={submitFunction} >

                {/* header */}
                <div className="header">
                    <h1>Update {setting[0].collection}</h1>
                    <Link onClick={() => { history.goBack() }}><FontAwesomeIcon icon={faMinusSquare} color="red" size="2x" /></Link>
                </div>

                {/* avader */}
                <div onClick={() => { document.getElementById('avader').click() }} className="avader" style={{ backgroundImage: `url(${Avader ? Avader : defoultAvader})` }}>
                    <FontAwesomeIcon icon={faPlus} color="#ccc" size="2x" />
                    <input type="file" id="avader" onChange={selectedFile} style={{ display: 'none' }} />
                </div>

                {/* inputs */}
                <input type="text" onChange={(e) => (setName(e.target.value))} value={Name} placeholder="Name" />
                <input type="email" onChange={(e) => { setEmail(e.target.value) }} value={Email} placeholder="email" />
                <input type="text" value={Phone} placeholder="phone" />
                <textarea onChange={(e) => { setAddrass(e.target.value) }} value={Addrass} placeholder="addrase" cols="30" rows="5"></textarea>

                {/* submit */}
                <input type="submit" value={`Update ${setting[0].collection}`} />

                {/* prograss */}
                <progress id="file" value={Progras} max="100"> {`${Progras} %`} </progress>
            </form>
        </div>
    )
}


export default Update;