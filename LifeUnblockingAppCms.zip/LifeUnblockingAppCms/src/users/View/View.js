import React, { useState, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheckSquare, faCoffee, faPlus, faMinusSquare } from '@fortawesome/free-solid-svg-icons'
import { useParams, Link } from "react-router-dom";
import { db } from '../../firebase';
import setting from '../setting.json'; // setting[0].collection
import './View.css';
import defoultAvader from '../../images/avatar-placeholder.webp'

function View() {

    // Route paramiter
    const { id } = useParams();

    //inputs
    const [Name, setName] = useState("");
    const [Email, setEmail] = useState("");
    const [Phone, setPhone] = useState("");
    const [Addrass, setAddrass] = useState("");
    const [Image, setImage] = useState("")

    useEffect(() => {
        db.collection(setting[0].collection).doc(id).get().then((e) => {
            const item = e.data();
            setName(item.name);
            setEmail(item.email);
            setPhone(item.phone);
            setAddrass(item.addrass);
            setImage(item.img);
        });
    }, []);


    return (
        <div className="View">
            <div className="view-section">
                <div className="header">
                    <h1>this is Viw item</h1>
                    <Link to={`/${setting[0].collection}`}><FontAwesomeIcon icon={faMinusSquare} color="red" size="2x" /></Link>
                </div>

                <hr />
                <img src={Image ? Image : defoultAvader} alt="" />
                <p><strong>Name: </strong>{Name}</p>
                <p><strong>Email: </strong>{Email}</p>
                <p><strong>Phone: </strong>{Phone}</p>
                <p><strong>Addrass: </strong>{Addrass}</p>
            </div>
        </div>
    )
}

export default View
