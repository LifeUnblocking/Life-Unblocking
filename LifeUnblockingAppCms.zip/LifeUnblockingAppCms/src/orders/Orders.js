import React, { useState, useEffect } from 'react'
import OrderItem from './OrderItem'
import { db } from '../firebase';
import './Orders.css'
import PrintAllTheProdact from './PrintAllTheProdact';

function Orders() {

    const [Users, setUsers] = useState([]);
    const [MargeProductList, setMargeProductList] = useState([])
    var alltheProduct = [];
    var fcmTokenList = [];
    var usersOrdersList = [];
    const serverKey = "AAAAb55PMrY:APA91bF34AbZMlXw1nAACXmC2unVcPkTCieHJ3WXpE3zCyWcPnN-Xpn4_DAkq8HKV4KgxB2Lfgp62e5laHiSmVQY0Azk09jZ1ohL2DHQznxTN18sg0q3JRjBm2w1s8_vJYHV2O3aQZD1";

    useEffect(() => {
        db.collection('users')
            .onSnapshot((snapshot) => {
                const data = snapshot.docs.map((doc) => {
                    let id = doc.id;
                    let data = doc.data()
                    return { id, ...data }
                });
                setUsers(data);
            });
    }, []);



    const getalltheProduct = () => {
        alltheProduct = [];
        fcmTokenList = [];
        usersOrdersList = [];
        Users.map( (user) =>db.collection('users')
        .doc(user.id)
        .collection('orders')
        .where('isCompleted', '==', false)
        .where('confirmMassage', '==', false)
        .get()
        .then((snapshot) => {
            snapshot.docs.map(doc => {
                let id  = doc.id;
                let data = doc.data();
                alltheProduct.push(...data.products);
                usersOrdersList.push({[user.id]: id})
                if(data.fcmToken)fcmTokenList.push(data.fcmToken);
            });
        }));

        // console.log(usersOrdersList)
    }

    const aasdfa = () => {
        var mergedList =  alltheProduct.reduce((acc,elem)=>{
            if(acc.filter((elemi)=>elemi.id==elem.id)[0])acc.filter((elemi)=>elemi.id==elem.id)[0].quantity+=elem.quantity;
            else acc.push(elem);
            return acc
        },[]);
        setMargeProductList(mergedList);


        
        //push notification
        //-------------------------------------
        var notification = {
            'title': 'আপনার অর্ডার সফল হয়েছে।',
            'body': 'আমরা সফলভাবে আপনার অর্ডারটি হাতে পেয়েছি। অতি দ্রুতই আপনার অর্ডারটি কার্যকর করা হবে। কোন প্রকার সহযোগিতার জন্য আমাদের হেল্পলাইনে যোগাযোগ করুন।',
            // 'click_action': 'http://localhost:8081'
        };
        var r = window.confirm("আপনি কি ইউজারদের নোটিফিকেশন পাঠাতে চান?");
        if (r == true) {
            fetch('https://fcm.googleapis.com/fcm/send', {
            'method': 'POST',
            'headers': {
              'Authorization': 'key=' + serverKey,
              'Content-Type': 'application/json'
            },
            'body': JSON.stringify({
              'notification': notification,
              'registration_ids': fcmTokenList
            })
        }).then(function(response) {
            
            //confirmation massages has been send
            //-------------------------------------
            for (const key in usersOrdersList) {
                if (Object.hasOwnProperty.call(usersOrdersList, key)) {
                    const element = usersOrdersList[key];
                    for (const [user, orderItem] of Object.entries(element)) {
                        db.collection('users')
                        .doc(user)
                        .collection('orders')
                        .doc(orderItem).update({confirmMassage: true})
                    }
                }
            }

            alert('done')

            console.log(response);
        }).catch(function(error) {
            console.error(error);
        });
        }

        
        


        
    }


    return (
        <div className="orders">

            <div className="head">
                <div>
                    <h1>Orders screen</h1>
                    <p>hey welcome to new cms</p>
                </div>
                <div>
                <button onClick={()=>getalltheProduct()}>marge all the product</button>
                <button onClick={()=>aasdfa()}>print</button>
                {
                    MargeProductList.length !== 0? <PrintAllTheProdact productsList={MargeProductList} />: null 
                }
                </div>
            </div>
            <hr />

            <div className="body">
                {
                    Users.map((user) => (<OrderItem key={user.id} user={user} />))
                }
            </div>
        </div>
    )
}

export default Orders
