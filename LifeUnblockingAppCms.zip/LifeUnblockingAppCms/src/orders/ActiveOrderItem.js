import React, { useState } from 'react'
import ViewOrderSection from './ViewOrder';
import PrintOrderSection from './PrintOrder';
import NotificationSection from './SendNotification';
import Countdown from "react-countdown";
import { Link } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEye, faPrint, faCommentDots, faTrash, faSign} from '@fortawesome/free-solid-svg-icons'
import { db } from '../firebase';

function ActiveOrderItem({ OrderItem, user, confirmOrder }) {

    const [ViewOrder, setViewOrder] = useState(false);
    const [PrintOrder, setPrintOrder] = useState(false)
    const [Notify, setNotify] = useState(false)


    const getOrders = () => {
        setPrintOrder(false);
        setNotify(false);
        setViewOrder(!ViewOrder);
    }
    const getPrinter = () => {
        setViewOrder(false);
        setNotify(false);
        setPrintOrder(!PrintOrder);
    }
    const SendNotification = () => {
        setViewOrder(false);
        setPrintOrder(false);
        setNotify(!Notify);
    }

    const deletetheOrder = (id)=>{
        var r = window.confirm("are your want to delete it realy");
        if (r == true) {
            db.collection('users')
            .doc(user.id)
            .collection('orders').doc(id).delete()
        }
    }

    const markAsCompleted = (id)=>{
        var r = window.confirm("are your want to mark this as completed");
        if (r == true) {
            db.collection('users')
            .doc(user.id)
            .collection('orders').doc(id).update({
                isCompleted: true
            })
        }
    }
    
    return (
        <div>
            <li className="orderItem" key={OrderItem.id} style={{backgroundColor: confirmOrder?'#6ac31821':'#ffffff'}}>
                {
                    !OrderItem.isCompleted ?
                        <Countdown date={new Date().setTime(OrderItem.orderTime) + 1000 * 60 * 60 * 24} />
                        : <span>Completed</span>
                }

                <div className="product_image_list">
                    {
                        OrderItem.products.map((p) => (<img key={p.imgs} src={p.imgs} alt="" />))
                    }
                </div>
                <p>{OrderItem.products.length}-items</p>
                {
                    OrderItem.fcmToken !== undefined ?
                        <Link title="send order confirem massage"><FontAwesomeIcon onClick={e=>SendNotification()} icon={faCommentDots} color="#6ac318" size="1x" /></Link>
                        : null
                }
                <Link><FontAwesomeIcon onClick={e => getPrinter()} icon={faPrint} color="#6ac318" size="1x" /></Link>
                <Link><FontAwesomeIcon onClick={e => getOrders()} icon={faEye} color="#6ac318" size="1x" /></Link>
                <Link><FontAwesomeIcon onClick={e => markAsCompleted(OrderItem.id)} icon={faSign} color="#6ac318" size="1x" /></Link>
                <Link><FontAwesomeIcon onClick={e => deletetheOrder(OrderItem.id)} icon={faTrash} color="#eb3434" size="1x" /></Link>
            </li>
            {ViewOrder ? <ViewOrderSection products={OrderItem.products} totalPrice={OrderItem.totalPrice} /> : null}
            {PrintOrder ? <PrintOrderSection user={user} products={OrderItem.products} totalPrice={OrderItem.totalPrice} /> : null}
            {Notify ? <NotificationSection user={user} fcmToken={OrderItem.fcmToken} /> : null}

        </div>
    )
}

export default ActiveOrderItem
