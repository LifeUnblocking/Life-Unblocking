import React, { useState } from 'react';
import defoultAvader from '../images/okbalogo.png';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEye, faPrint } from '@fortawesome/free-solid-svg-icons'

function PrintAllTheProdact({productsList}) {
    const [ReciptMassage, setReciptMassage] = useState(`we believe in quality food`);

    const printDiv = (divName) => {
        var content = document.getElementById(divName);
        var pri = document.getElementById("ifmcontentstoprint").contentWindow;
        pri.document.open();
        pri.document.write(content.innerHTML);
        pri.document.close();
        pri.focus();
        pri.print();
    }

    return (
        <div className="printOrder">
            <div className="PrintButtonSection">
                <button onClick={e => printDiv('printSection')} >Print</button>
            </div>
            <div id="printSection" style={{display: 'none'}}>
                <div style={{ padding: 0, margin: '0' }}>
                    <div
                        style={{
                            width: '100%',
                            margin: '0',
                            display: 'flex',
                            justifyContent: 'center',
                            alignItems: 'center',
                        }}>
                        <div>
                            <p
                                style={{
                                    padding: 0,
                                    margin: 0,
                                    fontSize: '30px',
                                    fontWeight: 'bold',
                                    zIndex: '9999999'
                                }}>OKBA</p>
                            <p
                                style={{
                                    padding: 0,
                                    margin: 0,
                                    fontSize: '13px',
                                    letterSpacing: '5px',
                                    zIndex: '9999999',
                                    marginTop: '-10px'
                                }}>delivery</p>
                        </div>
                        <img
                            style={{
                                width: '50px', height: '50px',
                                'z-index': '-9',
                            }}
                            src={defoultAvader} alt="" />

                    </div>

                    <p
                        style={{
                            padding: 0,
                            margin: 0,
                            width: '100%',
                            'z-index': '9999999',
                            'text-align': 'center',
                            lineHeight: '13px'
                        }}
                    >okba is an online shop to get the product's to your door</p>
                </div>
                <hr style={{ padding: 0, margin: '5px 0px 5px 0px' }} />
                <div className="info" style={{ padding: 0, margin: 0 }}>
                    <p style={{ padding: 0, margin: 0 }}>☎ 01601217191 </p>
                    <p style={{ padding: 0, margin: 0 }}>💬 www.okba.pw</p>
                    {/* <p style={{ padding: 0, margin: 0 }}>okbateam@gmail.com</p> */}
                </div>
                <hr style={{ padding: 0, margin: '5px 0px 13px 0px' }} />
                <ol style={{ paddingLeft: 10, margin: 0 }}>
                    {productsList.map(product => (
                        <li style={{ padding: 0, marginBottom: 5 }}>
                            <p style={{ padding: 0, margin: 0, fontSize: '12px' }}>{product.name}</p>
                            {/* <hr style={{ padding: 0, margin: 0 }} /> */}
                            <div className="Pricing" style={{ display: 'flex', justifyContent: 'space-between', padding: 0, margin: 0 }}>
                                <p style={{ padding: 0, margin: 0 }}>{product.weight} {product.price}tk</p>
                                {/* <p style={{ padding: 0, margin: 0 }}>------</p> */}
                                <p style={{ padding: 0, margin: 0}}><span style={{ padding: 0, margin: 0 , fontSize: '10px'}}>{product.brand}</span> {product.quantity}p</p>
                            </div>
                        </li>
                    ))}
                </ol>
                <hr style={{ padding: 0, margin: '0px' }} />
                {/* <p style={{ textAlign: 'right', padding: 0, margin: 0 }}>Total Price {totalPrice}</p> */}
                <hr style={{ padding: 0, margin: '15px 0px 5px 0px' }} />
                <p style={{ padding: 0, margin: 0 }}>{ReciptMassage}</p>
            </div>
            <iframe id="ifmcontentstoprint" style={{ height: '0px', width: '0px', position: 'absolute' }}></iframe>
        </div >
    )
}

export default PrintAllTheProdact
