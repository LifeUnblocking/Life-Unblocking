import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
import { db } from '../firebase';
import Countdown from "react-countdown";
import NotificationSection from './SendNotification';
import defoultAvader from '../images/avatar-placeholder.webp'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faLocationArrow, faEdit, faArrowDown, faArrowUp, faEye, faSignature, faCommentDots } from '@fortawesome/free-solid-svg-icons'
import ActiveOrderItem from './ActiveOrderItem'



function OrderItem({ user }) {

    // console.log(user)
    const [ActiveOrders, setActiveOrders] = useState([]);
    const [ConfirameOrder, setConfirameOrder] = useState([])
    const [CompletedOrders, setCompletedOrders] = useState([]);

    const [ActiveTabIsOpen, setActiveTabIsOpen] = useState(true);
    const [CompletedTabIsOpen, setCompletedTabIsOpen] = useState(false);

    const [Notify, setNotify] = useState(false)

    useEffect(() => {

        //active orders
        //--------------------------------
        db.collection('users')
            .doc(user.id)
            .collection('orders')
            .where('isCompleted', '==', false)
            .where('confirmMassage', '==', false)
            .onSnapshot(snapshot => {
                const orders = snapshot.docs.map(doc => {
                    let id = doc.id;
                    let data = doc.data();
                    return { id, ...data }
                });
                setActiveOrders(orders);
            });
        

        //confirm orders
        //----------------------------
        db.collection('users')
            .doc(user.id)
            .collection('orders')
            .where('isCompleted', '==', false)
            .where('confirmMassage', '==', true)
            .onSnapshot(snapshot => {
                const orders = snapshot.docs.map(doc => {
                    let id = doc.id;
                    let data = doc.data();
                    return { id, ...data }
                });
                setConfirameOrder(orders);
            });
        

        //completed orders
        //----------------------------
        db.collection('users')
            .doc(user.id)
            .collection('orders')
            .where('isCompleted', '==', true)
            .onSnapshot(snapshot => {
                const orders = snapshot.docs.map(doc => {
                    let id = doc.id;
                    let data = doc.data();
                    return { id, ...data }
                });
                setCompletedOrders(orders);
            });

    }, []);


    const getActiveOrders = () => {
        setCompletedTabIsOpen(false);
        setActiveTabIsOpen(!ActiveTabIsOpen);
    }
    const getCompletedOrders = () => {
        setActiveTabIsOpen(false);
        setCompletedTabIsOpen(!CompletedTabIsOpen);
    }

    const SendNotification = () => {
        setNotify(!Notify);
    }




    return (
        <div className="Order-item" style={{ display: ActiveOrders.length === 0 && ConfirameOrder.length ===0 ? "none" : 'block' }}>

            {/* user
            ----------------------------------*/}
            <div className="user">
                <div className="user-section">
                    {
                        user.img !== undefined ?
                            <div className="avader" style={{ backgroundImage: 'url(' + user.img + ')' }}></div>
                            : <div className="avader" style={{ backgroundImage: 'url(' + defoultAvader + ')' }}></div>
                    }
                    <div className="userInfo">
                        <p>Name: {user.name} </p>
                        <p>Phone: {user.phone.toString().substring(3)}</p>
                        <p>Address: {user.address}</p>
                        {
                            user.latLng !== undefined ?
                                <a target="blank" title="see Location" href={`http://maps.google.com/maps?saddr=23.639661,90.599600&daddr=${user.latLng.ef},${user.latLng.nf}`} ><FontAwesomeIcon icon={faLocationArrow} color="#6ac318" size="1x" /></a>
                                : null
                        }
                        {
                            user.fcmToken !== undefined ?
                                <Link title="send massage to this user"><FontAwesomeIcon onClick={e => SendNotification()} icon={faCommentDots} color="#6ac318" size="1x" /></Link>
                                : null
                        }
                        {Notify ? <NotificationSection user={user} fcmToken={user.fcmToken}  /> : null}
                    </div>
                </div>
                <p style={{ float: 'right' }}><Link to={`users/update-users/${user.id}`}><FontAwesomeIcon icon={faEdit} color="#6ac318" size="1x" /></Link></p>
            </div>

            {/* manule
            ------------------------------------- */}
            <ul className="orderItemMenu">
                <li>
                    <Link onClick={e => getActiveOrders()} style={{ backgroundColor: ActiveTabIsOpen ? '#ccc' : '#6ac319' }}>
                        <strong className="strong-active">{ActiveOrders.length}</strong>
                        active orders {ActiveTabIsOpen ?
                            <FontAwesomeIcon icon={faArrowUp} color="#fff" size="1x" />
                            : <FontAwesomeIcon icon={faArrowDown} color="#fff" size="1x" />}
                    </Link>
                </li>
                <li>
                    <Link onClick={e => getCompletedOrders()} style={{ backgroundColor: CompletedTabIsOpen ? '#ccc' : '#6ac319' }}>
                        {CompletedOrders.length} completed orders {CompletedTabIsOpen ?
                            <FontAwesomeIcon icon={faArrowUp} color="#fff" size="1x" />
                            : <FontAwesomeIcon icon={faArrowDown} color="#fff" size="1x" />}
                    </Link>
                </li>
            </ul>

            {/* active orders
            ----------------------------------------- */}
            {
                ActiveOrders.length !==0 ?  
                    ActiveTabIsOpen ?
                        <ul>
                            <h4>active orders</h4>
                            <hr/>
                            {ActiveOrders.map((OrderItem) => (
                                <ActiveOrderItem OrderItem={OrderItem} user={user} confirmOrder={false}/>
                            ))}
                        </ul> : null
                    :null
            }


            {/* confirm orders
            ----------------------------------------- */}
            {
                ConfirameOrder.length !==0 ?
                    ActiveTabIsOpen ?
                        <ul>
                            <h4>Confirm Orders</h4>
                            <hr/>
                            {ConfirameOrder.map((OrderItem) => (
                                <ActiveOrderItem OrderItem={OrderItem} user={user} confirmOrder={true}/>
                            ))}
                        </ul> : null
                    :null
            }

            {/* completed orders
            ---------------------------------------- */}
            {
                CompletedTabIsOpen ?
                    <ul>
                        <h4>completed orders</h4>
                        {
                            CompletedOrders.length !== 0 ?
                                CompletedOrders.map((o) => (<li className="orderItem" key={o.id}>
                                    {
                                        !o.isCompleted ?
                                            <Countdown date={new Date().setTime(o.orderTime) + 1000 * 60 * 60 * 24} />
                                            : <span><FontAwesomeIcon icon={faSignature} color="#6ac318" size="1x" /></span>
                                    }

                                    <div className="product_image_list">
                                        {
                                            o.products.map((p) => (<img key={p.imgs} src={p.imgs} alt="" />))
                                        }
                                    </div>
                                    <FontAwesomeIcon icon={faEye} color="#6ac318" size="1x" />
                                </li>)) : <li><p>no item</p></li>

                        }
                    </ul> : null
            }


        </div>
    )
}

export default OrderItem
