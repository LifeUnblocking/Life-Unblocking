import React, { useState } from 'react';

function SendNotification({ fcmToken }) {

    const [Image, setImage] = useState('')
    const [Title, setTitle] = useState('আপনার অর্ডার সফল হয়েছে।')
    const [Message, setMessage] = useState('আমরা সফলভাবে আপনার অর্ডারটি হাতে পেয়েছি। অতি দ্রুতই আপনার অর্ডারটি কার্যকর করা হবে। কোন প্রকার সহযোগিতার জন্য আমাদের হেল্পলাইনে যোগাযোগ করুন।')

    const serverKey = "AAAAb55PMrY:APA91bF34AbZMlXw1nAACXmC2unVcPkTCieHJ3WXpE3zCyWcPnN-Xpn4_DAkq8HKV4KgxB2Lfgp62e5laHiSmVQY0Azk09jZ1ohL2DHQznxTN18sg0q3JRjBm2w1s8_vJYHV2O3aQZD1";
    const icon = "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/Instagram_icon.png/1024px-Instagram_icon.png"
    
    const SendPushNotification = async () => {
        var notification = {
            'title': Title,
            'body': Message,
            'icon': icon,
            // 'click_action': 'http://localhost:8081'
          };
          
          fetch('https://fcm.googleapis.com/fcm/send', {
            'method': 'POST',
            'headers': {
              'Authorization': 'key=' + serverKey,
              'Content-Type': 'application/json'
            },
            'body': JSON.stringify({
              'notification': notification,
              'to': fcmToken
            })
          }).then(function(response) {
            alert('done')
            console.log(response);
          }).catch(function(error) {
            console.error(error);
          })
    }


    return (
        <div className="NotificationSection">
            <h3>Send Notification</h3>
            <div className="mainSection">
                <table>
                    <tr>
                        <td>Title</td>
                        <td><input onChange={(e) => (setTitle(e.target.value))} value={Title} type="text" /></td>
                    </tr>
                    <tr>
                        <td>Image(url)</td>
                        <td><input onChange={(e) => (setImage(e.target.value))} value={Image} type="text" /></td>
                    </tr>
                    <tr>
                        <td>Message</td>
                        <td><textarea onChange={(e) => (setMessage(e.target.value))} value={Message} cols="50" rows="8"></textarea></td>
                    </tr>
                </table>
                <div className="previwSection">
                    <p className="title"><strong>{Title !== '' ? Title : "Title..."}</strong></p>
                    <p className="massage">{Message !== '' ? Message : "massage body..."}</p>
                    <div style={{ backgroundImage: `url("${Image}")`, backgroundColor: "#ccc" }}></div>
                    <button onClick={e => SendPushNotification()}>Send</button>
                </div>
            </div>

        </div>
    )
}

export default SendNotification
