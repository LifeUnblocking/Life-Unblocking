import React from 'react'
import './Orders.css'

function ViewOrder({ products, totalPrice }) {
    return (
        <div className="ViewOrders">
            <ol>
                {products.map(product => (
                    <li key={product}>
                        <img src={product.imgs} alt="" />
                        <div className="brandNAme">
                            <p>brand: {product.brand}</p><br />
                            <p>name: {product.name}</p>
                        </div>

                        <div className="Pricing">
                            <p>{product.weight}, {product.price}tk</p>
                            <p>x</p>
                            <p style={{ float: 'right' }}>{product.quantity}p = {product.quantity * product.price}tk</p>
                        </div>

                    </li>
                ))}
            </ol>
            <hr />
            <p style={{ float: 'right' }}>total Price {totalPrice}</p>
        </div>
    )
}

export default ViewOrder
