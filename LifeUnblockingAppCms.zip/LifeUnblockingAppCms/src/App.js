import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import './App.css';
import Menu from './menu/Menu';

//FOR THE USER
import Users from './users/Lists/Lists';
import Category from './category/Lists/Lists';
import Product from './product/Lists/Lists';
import Home from './home/Home';
import Orders from './orders/Orders';
import UserVarification from './UserVarification/UserVarification';



function App() {
  return (
    <Router>
      <div className="App">
        <div className="container">
          <Menu></Menu>
          <Switch>
            {/* user */}
            <Route path="/users" children={<Users />} />

            {/* category */}
            <Route path="/category" children={<Category />} />

            {/* product */}
            <Route path="/news" children={<Product />} />

            {/* orders */}
            <Route path="/orders" children={<Orders />} />
            
            {/* user varification */}
            <Route path="/userVarification" children={<UserVarification />} />


            {/* HOME PAGE */}
            <Route path="/" children={<Home />} />
          </Switch>

        </div>
      </div>

    </Router>

  );
}

export default App;
