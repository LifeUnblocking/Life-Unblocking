import React, { useState, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMinusSquare } from '@fortawesome/free-solid-svg-icons';
import { useParams, Link } from "react-router-dom";
import { db } from '../../firebase';
import setting from '../setting.json'; // setting[0].collection
import './View.css';
import defoultAvader from '../../images/_HYHtD8F.jpg'

function View() {

    // Route paramiter
    const { id } = useParams();

    //inputs
    const [Name, setName] = useState("");
    const [About, setAbout] = useState("")
    const [Image, setImage] = useState("")

    useEffect(() => {
        db.collection(setting[0].collection).doc(id).get().then((e) => {
            const item = e.data();
            setName(item.name);
            setAbout(item.about);
            setImage(item.img);
        });
    }, []);


    return (
        <div className="View">
            <div className="view-section">
                <div className="header">
                    <h1 style={{margin: 0}}>this is Viw item</h1>
                    <Link to={`/${setting[0].collection}`}><FontAwesomeIcon icon={faMinusSquare} color="red" size="2x" /></Link>
                </div>

                <hr />
                <img src={Image ? Image : defoultAvader} alt="" />
                <p><strong>Name: </strong>{Name}</p>
                <p><strong>About: </strong>{About}</p>
            </div>
        </div>
    )
}

export default View
