import React, { useState } from 'react';
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheckSquare, faCoffee, faPlus, faMinusSquare } from '@fortawesome/free-solid-svg-icons'
import { db, storeage } from '../../firebase';
import setting from '../setting.json'; // setting[0].collection
import firebase from 'firebase';
import './AddItem.css'
import defoultAvader from '../../images/_HYHtD8F.jpg'

function AddItem() {

    //input
    const [Name, setName] = useState("");
    const [About, setAbout] = useState("");
    const [Status, setStatus] = useState("Publish");
    const [Priority, setPriority] = useState("");
    const [Visible, setVisible] = useState("false");
    const [PriorityLavel, setPriorityLavel] = useState([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59])

    //avader file
    const [Avader, setAvader] = useState("");
    const [Image, setImage] = useState("");
    const [Progras, setProgras] = useState("")

    const submitFunction = ((e) => {
        if (Name && About && Visible) {

            if (Image) {
                const uploadTask = storeage.ref(`${setting[0].collection}/${Image.name}`).put(Image);
                uploadTask.on(
                    "state_changed",
                    (snapshort) => {
                        const prograss = Math.round((snapshort.bytesTransferred / snapshort.totalBytes) * 100);
                        setProgras(prograss);
                    },
                    (error) => {
                        alert(error.message);
                    },
                    () => {
                        storeage.ref(setting[0].collection).child(Image.name).getDownloadURL().then((url) => {
                            db.collection(setting[0].collection).add({
                                name: Name,
                                about: About,
                                img: url,
                                status: Status,
                                // priority: Priority,
                                // visible: Visible == "true" ? true : false,
                                timestamp: firebase.firestore.FieldValue.serverTimestamp(),
                            }).then(() => {
                                console.log(`${setting[0].collection} has been added`);
                                setName('');
                                setAbout('');
                                setPriority('');
                            });
                        });
                    }
                );
            } else {
                db.collection(setting[0].collection).add({
                    name: Name,
                    about: About,
                    status: Status,
                    // priority: Priority,
                    // visible: Visible == "true" ? true : false,
                    timestamp: firebase.firestore.FieldValue.serverTimestamp(),
                }).then(() => {
                    console.log(`${setting[0].collection} has been added`);
                    setName('');
                    setAbout('');
                    setPriority('');
                });
            }
        } else {
            console.log('please seet all the imput');
        }

        e.preventDefault();
    });


    //previw images
    const selectedFile = ((e) => {
        var file = document.getElementById('avader').files[0];
        setAvader(window.URL.createObjectURL(file));
        setImage(file);
    });

    return (
        <div className="AddItem">
            <form onSubmit={submitFunction} >
                {/* HEADER */}
                <div className="header">
                    <h1 style={{margin: 0}}>Add {setting[0].collection}</h1>
                    <Link to={`/${setting[0].collection}`}><FontAwesomeIcon icon={faMinusSquare} color="red" size="2x" /></Link>
                </div>

                {/* AVADER */}
                <div onClick={() => { document.getElementById('avader').click() }} className="avader" style={{ backgroundImage: `url(${Avader ? Avader : defoultAvader})` }}>
                    {/* <span>add</span> */}
                    <FontAwesomeIcon icon={faPlus} color="#ccc" size="3x" />
                    <input type="file" id="avader" onChange={selectedFile} style={{ display: 'none' }} />
                </div>
                <br/>


                {/* INPUTS */}
                <input type="text" onChange={(e) => (setName(e.target.value))} value={Name} placeholder="Name" />
                <textarea onChange={(e) => { setAbout(e.target.value) }} value={About} placeholder="Description" cols="30" rows="5"></textarea>
                {/* <input type="text" onChange={(e) => (setPriority(e.target.value))} value={Priority} placeholder="Priority" /> */}
                {/* <label>
                    Priority:
                    <select value={Priority} onChange={(e) => (setPriority(e.target.value))}>
                        <option value="none">none</option>
                        {PriorityLavel.map((e) => (<option value={e}>{e}</option>))}
                    </select>
                </label> */}
                <label>
                    status:
                    <select value={Status} onChange={(e) => (setStatus(e.target.value))}>
                        <option value="Unpublish">Unpublish</option>
                        <option value="Publish">Publish</option>
                    </select>
                </label>
                <br/>
                {/* <label>
                    visible:
                    <select value={Visible} onChange={(e) => (setVisible(e.target.value))}>
                        <option value={true}>on</option>
                        <option value={false}>off</option>
                    </select>
                </label> */}

                {/* SUBMIT */}
                <input type="submit" value={`Add ${setting[0].collection}`} />

                {/* PROGRASS */}
                <progress id="file" value={Progras} max="100"> {`${Progras} %`} </progress>
            </form>
        </div>
    )
}


export default AddItem;