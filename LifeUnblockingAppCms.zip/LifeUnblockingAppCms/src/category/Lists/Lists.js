import React, { useEffect, useState } from 'react';
import { Link, Switch, Route, useRouteMatch } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTrash, faEye, faEdit} from '@fortawesome/free-solid-svg-icons';
import { db, storeage } from '../../firebase';
import setting from '../setting.json'; // setting[0].collection
import './Lists.css';
import View from '../View/View';
import Update from '../Update/Update';
import AddItem from '../Add/AddItem';
import defoultAvader from '../../images/_HYHtD8F.jpg'



function Lists() {

    let match = useRouteMatch();


    //CATAGORY LIST
    const [List, setList] = useState([]);

    // PRIORITY
    const [Priority, setPriority] = useState("");
    const [PriorityLavel, setPriorityLavel] = useState([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59])

    // firebase
    useEffect(() => {
        db.collection(setting[0].collection).onSnapshot(snapshot => {
            const data = snapshot.docs.map(doc => {
                let id = doc.id;
                let data = doc.data();
                return { id, ...data }
            });
            setList(data);
        });
    }, []);

    //DELETE 
    const remove = (id, imageurl) => {
        var r = window.confirm(`do you want to delete this ${setting[0].collection}?`);
        if (r == true) {
            if (imageurl !== undefined) {
                var desertRef = storeage.ref().child(getFilename(imageurl));
                desertRef.delete().then(function () {
                    db.collection(setting[0].collection).doc(id).delete()
                }).catch(function (error) {
                    alert(error);
                });
            } else {
                db.collection(setting[0].collection).doc(id).delete()
            }
        }
        
    }
    function getFilename(url) {
        const filename = decodeURIComponent(new URL(url).pathname.split('/').pop());
        if (!filename) return null; // some default filename
        return filename;
    }


    //CHANGE STATUS
    const changeStatus = (id) => {
        db.collection(setting[0].collection).doc(id).get().then((data) => {
            db.collection(setting[0].collection).doc(id).update({
                status: data.data().status === "Unpublish" ? "Publish" : "Unpublish"
            });
        });
    }

    //CHANGE PRIORITY
    const changePriority = (id, e) => {
        db.collection(setting[0].collection).doc(id).update({
            priority: e
        });
    }


    return (
        <div className="Lists">
            <div className="head">
                <div>
                    <h1>all the {setting[0].collection}</h1>
                    <p>{List.length} {setting[0].collection} found</p>
                </div>
                <div>
                    <Link to={`${match.url}/add-${setting[0].collection}`}>
                        <button className="addbutton">add {setting[0].collection}</button>
                    </Link>
                </div>
            </div>
            <hr />

            <table style={{ width: "100%" }}>
                <thead>
                    <tr>
                        <th>image</th>
                        <th>Name</th>
                        <th>Description</th>
                        {/* <th>Priority</th> */}
                        <th>Status</th>
                    </tr>
                </thead>

                <tbody>
                    {List.map(item => (
                        <tr key={item.id}>
                            <td>
                                <img
                                    style={!item.img ? { opacity: 0.2 } : null}
                                    className="avader"
                                    src={item.img ? item.img : defoultAvader}
                                    alt="" />
                            </td>
                            <td>{item.name}</td>
                            <td>{item.about}</td>
                            {/* <td>
                                <select value={Priority} onChange={(e) => (changePriority(item.id, e.target.value))}>
                                    <option value={item.priority}>{item.priority}</option>
                                    {PriorityLavel.map((e) => (<option key={e} value={e}>{e}</option>))}
                                </select>
                            </td> */}
                            <td><button onClick={(e) => { changeStatus(item.id) }}>{item.status}</button></td>
                            {/* <td><Link to={`${match.url}/view-${setting[0].collection}/${item.id}`}><FontAwesomeIcon icon={faEye} color="#6ac318" size="1x" /></Link></td> */}
                            <td><Link to={`${match.url}/update-${setting[0].collection}/${item.id}`}><FontAwesomeIcon icon={faEdit} color="#6ac318" size="1x" /></Link></td>
                            <td><FontAwesomeIcon onClick={(e) => { remove(item.id, item.img) }} icon={faTrash} color="red" size="1x" /></td>
                        </tr>
                    ))}
                </tbody>
            </table>

            {List.length === 0 ? <NoiTemsFound /> : null}


            <Switch>
                {/* ADD USER */}
                <Route path={`${match.url}/add-${setting[0].collection}`} children={<AddItem />} />

                {/* UPDATE USER */}
                <Route path={`${match.url}/update-${setting[0].collection}/:id`} children={<Update />} />

                {/* VIEW USER */}
                <Route path={`${match.url}/view-${setting[0].collection}/:id`} children={<View />} />
            </Switch>
        </div>
    )
}

function NoiTemsFound() {
    return (
        <div className="NoiTemsFound">
            <h1>here no item availe availe</h1>
            <p>add item</p>
        </div>
    );
}

export default Lists


