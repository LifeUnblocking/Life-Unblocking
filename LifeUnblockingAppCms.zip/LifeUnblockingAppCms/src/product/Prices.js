import React, { useState } from 'react'
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import { db } from '../firebase';
import setting from './setting.json'; // setting[0].collection

function Prices({ product }) {

    const [WeightOptionList, setWeightOptionList] = useState([...product.weightOption])
    // const [WeightOption, setWeightOption] = useState("");
    // const [WeightPrice, setWeightPrice] = useState("")

    const removeWeightOption = (e) => {
        var filtered = WeightOptionList.filter(function (el) { return el.option !== e; });
        setWeightOptionList(filtered);
    }

    const reorder = (list, startIndex, endIndex) => {
        const result = Array.from(list);
        const [removed] = result.splice(startIndex, 1);
        result.splice(endIndex, 0, removed);
        return result;
    };

    const onEnd = (result) => {
        db.collection(setting[0].collection).doc(product.id).update({
            weightOption: reorder(WeightOptionList, result.source.index, result.destination.index)
        }).then(() => {
            console.log('has update')
        });
        setWeightOptionList(reorder(WeightOptionList, result.source.index, result.destination.index))
    }

    return (
        <div style={{
            width: '150px',
        }}>

            <DragDropContext onDragEnd={onEnd}>
                <Droppable
                    droppableId="123570934"

                >
                    {(provided, snapshort) => (
                        <div
                            ref={provided.innerRef}
                            style={{
                                width: '150px',
                                overflow: 'hidden'
                            }}
                        >
                            {
                                WeightOptionList.map((item, index) => (
                                    <Draggable
                                        draggableId={item.option + index}
                                        key={item.option + index}
                                        index={index}
                                    >
                                        {(provided, snapshort) => (
                                            <div
                                                ref={provided.innerRef}
                                                {...provided.draggableProps}
                                                {...provided.dragHandleProps}
                                            >
                                                <div
                                                    style={{
                                                        backgroundColor: '#ccc',
                                                        margin: '0',
                                                        padding: 3,
                                                        display: "inline-block"
                                                    }}
                                                >
                                                    {item.option} = tk{item.price}
                                                    <strong
                                                        style={{
                                                            cursor: 'pointer',
                                                            color: 'red'
                                                        }}
                                                        onClick={() => removeWeightOption(item.option)}>x</strong>
                                                </div>
                                            </div>
                                        )}

                                    </Draggable>
                                ))
                            }

                            {provided.placeholder}
                        </div>
                    )}
                </Droppable>
            </DragDropContext>

            {/* <input type="text" onChange={(e) => (setWeightOption(e.target.value))} value={WeightOption} placeholder="option" />
            <input type="number" onChange={(e) => (setWeightPrice(e.target.value))} value={WeightPrice} placeholder="price" />
            <button style={{ fontSize: "18px" }} onClick={(e) => {
                setWeightOptionList([...WeightOptionList, { option: WeightOption, price: WeightPrice }])
                setWeightOption('')
                setWeightPrice('')
                e.preventDefault();
            }}>add</button> */}

        </div>
    )
}

export default Prices
