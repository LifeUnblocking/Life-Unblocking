import React, { useEffect, useState } from 'react';
import { Link, Switch, Route, useRouteMatch } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTrash, faEye, faEdit, faArrowLeft, faArrowRight } from '@fortawesome/free-solid-svg-icons';
import defoultAvader from '../../images/_HYHtD8F.jpg';
import { db } from '../../firebase';
import setting from '../setting.json'; // setting[0].collection
import './Lists.css';
import View from '../View/View';
import Update from '../Update/Update';
import AddItem from '../Add/AddItem';
import Images from '../Images'
import Prices from '../Prices'
import Catagorytable from '../Catagory'




function Lists() {


    let match = useRouteMatch();

    const [List, setList] = useState([]);

    //catagoryLists
    const [CatagoryLists, setCatagoryLists] = useState([]);

    //pagination
    const [PostParPage, setPostParPage] = useState(10)
    const [TotalPostes, setTotalPostes] = useState(0)
    const [PageCounter, setPageCounter] = useState(0)
    const [PaginationVisibality, setPaginationVisibality] = useState(false)

    //checkbox filter
    const [PublishChckBox, setPublishChckBox] = useState(true)
    const [UnpublishChckBox, setUnpublishChckBox] = useState(true)
    const [availableChckBox, setavailableChckBox] = useState(true)
    const [UnavailableChckBox, setUnavailableChckBox] = useState(true)

    // useEffect
    //----------------------------------------
    useEffect(() => {

        filterTheCatagory()

        db.collection("category")
            .orderBy('timestamp', 'desc')
            .onSnapshot(snapshot => {
                const data = snapshot.docs.map(doc => {
                    let id = doc.id;
                    let data = doc.data();
                    return { id, ...data }
                });
                setCatagoryLists(data);
            });

        db.collection(setting[0].collection).onSnapshot(snapshot => {
            setTotalPostes(snapshot.docs.length)
        });
    }, []);


    //filter catagory 
    //----------------------------------------
    const filterTheCatagory = (value) => {
        if (value !== undefined && value !== 'none') {
            db.collection(setting[0].collection)
                .where('catagory', 'array-contains', value)
                .orderBy('timestamp', 'desc')
                .onSnapshot(snapshot => {
                    const data = snapshot.docs.map(doc => {
                        let id = doc.id;
                        let data = doc.data();
                        return { id, ...data }
                    });
                    setList(data);
                    setPageCounter(snapshot.docs.length);
                    setPaginationVisibality(false)
                });
        } else {
            db.collection(setting[0].collection)
                .orderBy('timestamp', 'desc')
                .limit(PostParPage)
                .onSnapshot(snapshot => {
                    const data = snapshot.docs.map(doc => {
                        let id = doc.id;
                        let data = doc.data();
                        return { id, ...data }
                    });
                    setList(data);
                    setPageCounter(snapshot.docs.length);
                    setPaginationVisibality(true)
                });
        }
    }

    //go to next
    //------------------------------------------
    const GotoNext = () => {
        db.collection(setting[0].collection)
            .orderBy('timestamp', 'desc')
            .startAfter(List.slice(-1)[0].timestamp)
            .limit(PostParPage)
            .onSnapshot(snapshot => {
                const data = snapshot.docs.map(doc => {
                    let id = doc.id;
                    let data = doc.data();
                    return { id, ...data }
                });
                setList(data);
                setPageCounter(PageCounter + PostParPage);
                document.getElementById("mainScrollBody").scrollTo({ top: 0, behavior: "smooth" });
            });
    }

    //go to privius
    //------------------------------------------
    const GotoPrivus = () => {
        db.collection(setting[0].collection)
            .orderBy('timestamp', 'desc')
            .endBefore(List.slice(-1)[0].timestamp)
            .limit(PostParPage)
            .onSnapshot(snapshot => {
                const data = snapshot.docs.map(doc => {
                    let id = doc.id;
                    let data = doc.data();
                    return { id, ...data }
                });
                setList(data);
                setPageCounter(PageCounter - PostParPage);
                document.getElementById("mainScrollBody").scrollTo({ top: 0, behavior: "smooth" });
            });
    }



    //Ailability
    //-----------------------------------------
    const changeavAilability = (id) => {
        db.collection(setting[0].collection).doc(id).get().then((data) => {
            db.collection(setting[0].collection).doc(id).update({
                isAvailable: data.data().isAvailable ? false : true
            });
        });
    }


    //Publish the item
    //----------------------------------------
    const changeStatus = (id) => {
        db.collection(setting[0].collection).doc(id).get().then((data) => {
            db.collection(setting[0].collection).doc(id).update({
                status: data.data().status == "Unpublish" ? "Publish" : "Unpublish"
            });
        });
    }

    //DELETE POST
    //---------------------------------------------
    const remove = (id, imageurl) => {
        var r = window.confirm(`do you want to delete this ${setting[0].collection}?`);
        if (r == true) {
            if(imageurl){
                if (imageurl.length == 0) {
                    db.collection(setting[0].collection).doc(id).delete();
                   filterTheCatagory();
                } else {
                    alert('please delete image first');
                }
            }else{
                db.collection(setting[0].collection).doc(id).delete();
               filterTheCatagory();
            }
        }
    }

    return (
        <div className="Lists" id="mainScrollBody">
            <div className="head">
                <div>
                    <h1>all the {setting[0].collection}</h1>
                    <p>{PageCounter} / {TotalPostes} {setting[0].collection} found</p>
                </div>
                <div>
                    <Link to={`${match.url}/add-${setting[0].collection}`}>
                        <button className="addbutton">
                            add {setting[0].collection}
                        </button>
                    </Link>
                </div>
            </div>
            <hr />
            <div className="filter-secdtion">
                <select onChange={e => filterTheCatagory(e.target.value)}>
                    <option value="none">all news</option>
                    {
                        CatagoryLists.map((data) => (
                            <option key={data.id} value={data.name}>{data.name}</option>
                        ))
                    }
                </select>
                <div className="checkbox-filter" style={{ float: 'right' }}>
                    {
                        PaginationVisibality ? <div style={{ display: 'inline-block' }}>
                            <button onClick={e => GotoPrivus()} disabled={PageCounter <= PostParPage ? true : false}><FontAwesomeIcon icon={faArrowLeft} color="#6ac318" size="1x" /></button>
                            <input style={{ width: '50px' }} type="number" value={PostParPage} onChange={e => setPostParPage(parseInt(e.target.value))} />
                            <button onClick={e => GotoNext()} disabled={PageCounter >= TotalPostes ? true : false}><FontAwesomeIcon icon={faArrowRight} color="#6ac318" size="1x" /></button>
                        </div> : null
                    }
                    {/* <input type="checkbox" id="publish" value="publish" checked={PublishChckBox} onChange={e => setPublishChckBox(!PublishChckBox)} />
                    <label for="publish">Publish</label>

                    <input type="checkbox" id="unpublish" value="unpublish" checked={UnpublishChckBox} onChange={e => setUnpublishChckBox(!UnpublishChckBox)} />
                    <label for="unpublish">Unpublish</label>

                    <input type="checkbox" id="available" value="available" checked={availableChckBox} onChange={e => setavailableChckBox(!availableChckBox)} />
                    <label for="available">Available</label>

                    <input type="checkbox" id="unavilable" value="unavilable" checked={UnavailableChckBox} onChange={e => setUnavailableChckBox(!UnavailableChckBox)} />
                    <label for="unavilable">Unavailable</label> */}
                </div>
            </div>
            <progress style={{ width: '100%' }} value={PageCounter} max={TotalPostes}> {PageCounter}% </progress>

            <table style={{ width: "100%" }}>

                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Title</th>
                        <th>News</th>
                        {/* <th>brand</th> */}
                        <th>Catagory</th>
                        <th>Status</th>
                        {/* <th>Avality</th> */}
                    </tr>
                </thead>

                <tbody>
                    {List.map(item => (
                        <tr key={item.id}>
                            <td>
                                {
                                    item.img ?
                                        <Images key={item} product={item} />
                                        : <img className="avader" src={defoultAvader} alt="" style={{ opacity: 0.2 }} />
                                }
                            </td>
                            <td>{item.name}</td>
                            <td>{item.about}</td>
                            {/* <td>
                                {
                                    item.weightOption !== undefined ?
                                        <Prices product={item} />
                                        : item.price
                                }
                            </td> */}
                            {/* <td>{item.brand}</td> */}
                            <td>
                                <Catagorytable
                                    product={item}
                                    CatagoryLists={CatagoryLists} />
                            </td>
                            <td>
                                <button
                                    onClick={e => changeStatus(item.id)}>
                                    {item.status}
                                </button>
                            </td>
                            {/* <td>
                                <button
                                    onClick={e => changeavAilability(item.id)}>
                                    {item.isAvailable != null && !item.isAvailable ? 'Unavailable' : 'Available'}
                                </button>
                            </td> */}

                            {/* <td><Link to={`${match.url}/view-${setting[0].collection}/${item.id}`}><FontAwesomeIcon icon={faEye} color="#6ac318" size="1x" /></Link></td> */}
                            <td><Link to={`${match.url}/update-${setting[0].collection}/${item.id}`}><FontAwesomeIcon icon={faEdit} color="#6ac318" size="1x" /></Link></td>
                            <td><Link to="#"><FontAwesomeIcon onClick={(e) => { remove(item.id, item.img) }} icon={faTrash} color="red" size="1x" /></Link></td>
                        </tr>
                    ))}
                </tbody>
            </table>

            {List.length == 0 ? <NoiTemsFound /> : null}
            {
                PaginationVisibality ? <div>
                    <button onClick={e => GotoPrivus()} disabled={PageCounter <= PostParPage ? true : false}><FontAwesomeIcon icon={faArrowLeft} color="#6ac318" size="1x" /></button>
                    <input style={{ width: '50px' }} type="number" value={PostParPage} onChange={e => setPostParPage(parseInt(e.target.value))} />
                    <button onClick={e => GotoNext()} disabled={PageCounter >= TotalPostes ? true : false}><FontAwesomeIcon icon={faArrowRight} color="#6ac318" size="1x" /></button>
                </div> : null
            }


            <Switch>
                {/* ADD USER */}
                <Route path={`${match.url}/add-${setting[0].collection}`} children={<AddItem />} />

                {/* UPDATE USER */}
                <Route path={`${match.url}/update-${setting[0].collection}/:id`} children={<Update />} />

                {/* VIEW USER */}
                <Route path={`${match.url}/view-${setting[0].collection}/:id`} children={<View />} />
            </Switch>
        </div>
    )
}

function NoiTemsFound() {
    return (
        <div className="NoiTemsFound">
            <h1>here no item availe availe</h1>
            <p>add item</p>
        </div>
    );
}

export default Lists


