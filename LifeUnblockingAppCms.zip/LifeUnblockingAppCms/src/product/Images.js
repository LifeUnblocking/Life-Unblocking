import React, { useState } from 'react';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import defoultAvader from '../images/_HYHtD8F.jpg';
import setting from './setting.json'; // setting[0].collection
import { db, storeage } from '../firebase';


function Images({ product }) {

    const [ImagesLists, setImagesLists] = useState([...product.img])

    //DELETE POST
    const remove = (imageurl) => {
        if (imageurl !== undefined) {
            storeage.ref().child(getFilename(imageurl)).delete().then(function () {
                db.collection(setting[0].collection).doc(product.id).update({
                    img: product.img.filter((v) => imageurl !== v ? v : null)
                });
            }).catch(function (error) {
                if (error.code === "storage/object-not-found") {
                    var r = window.confirm("Image not found\ndo you want to delete image link");
                    if (r === true) {
                        db.collection(setting[0].collection).doc(product.id).update({
                            img: product.img.filter((v) => imageurl !== v ? v : null)
                        });
                    }
                }
            });
        }
    }

    function getFilename(url) {
        const filename = decodeURIComponent(new URL(url).pathname.split('/').pop());
        if (!filename) return null; // some default filename
        return filename;
    }

    const reorder = (list, startIndex, endIndex) => {
        const result = Array.from(list);
        const [removed] = result.splice(startIndex, 1);
        result.splice(endIndex, 0, removed);
        return result;
    };

    const onEnd = (result) => {
        db.collection(setting[0].collection).doc(product.id).update({
            img: reorder(ImagesLists, result.source.index, result.destination.index)
        }).then(() => {
            console.log('has update')
        });
        setImagesLists(reorder(ImagesLists, result.source.index, result.destination.index))
    }

    return (
        <div>
            {
                product.img ?
                    <DragDropContext onDragEnd={onEnd}>
                        <Droppable
                            droppableId="123570sdfasd934"
                        >
                            {(provided, snapshort) => (
                                <div
                                    ref={provided.innerRef}
                                    style={{
                                        // width: '100px',
                                        // overflow: 'hidden'
                                    }}
                                >
                                    {
                                        ImagesLists.map((image, index) => (
                                            <Draggable
                                                draggableId={image+index}
                                                key={index}
                                                index={index}
                                            >
                                                {(provided, snapshort) => (
                                                    <div
                                                        ref={provided.innerRef}
                                                        {...provided.draggableProps}
                                                        {...provided.dragHandleProps}
                                                    >
                                                        <div key={image} style={{
                                                            display: "flex",
                                                            justifyContent: 'end',
                                                            alignItems: 'start'
                                                        }}>
                                                            <img className="avader" src={image ? image : defoultAvader} alt="" />
                                                            <span style={{ cursor: "pointer", color: "red" }}>
                                                                <strong onClick={() => (remove(image))}>x</strong>
                                                            </span>
                                                        </div>
                                                    </div>
                                                )}
                                            </Draggable>

                                        ))
                                    }
                                    {provided.placeholder}
                                </div>
                            )}
                        </Droppable>
                    </DragDropContext>

                    : <img className="avader" src={defoultAvader} alt="" style={{ opacity: 0.2 }} />
            }
        </div>
    )
}

export default Images
