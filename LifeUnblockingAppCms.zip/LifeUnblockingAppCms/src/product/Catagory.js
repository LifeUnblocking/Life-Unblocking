import React from 'react'
import { db } from '../firebase';
import setting from './setting.json'; // setting[0].collection

function Catagory({ product, CatagoryLists }) {

    //filter catagory 
    //----------------------------------------
    const changeCatagory = (e, data) => {
        db.collection(setting[0].collection).doc(product.id).update({
            catagory: [...data, e]
        });
    }
    const removeCatagoryItem = (e, data) => {
        db.collection(setting[0].collection).doc(product.id).update({
            catagory: data.filter((v) => e != v ? v : null)
        });
    }

    return (
        <div>
            {/* CATAGORY LIST */}
            <div className="catagorySpan">
                {
                    product.catagory
                        ? product.catagory.map((catagoryItem) => (
                            <span
                                key={catagoryItem}>
                                {catagoryItem}
                                <strong
                                    onClick={e => removeCatagoryItem(catagoryItem, product.catagory)}>
                                    x
                            </strong>
                            </span>
                        ))
                        : null
                }
            </div>

            {/* CATAGORY LIST SELECTION */}
            <select onChange={e => changeCatagory(e.target.value, product.catagory)}>
                <option value="none">add catagory</option>
                {
                    CatagoryLists.map((data) => (
                        <option key={data.name} value={data.name}>{data.name}</option>
                    ))
                }
            </select>
        </div>
    )
}

export default Catagory
