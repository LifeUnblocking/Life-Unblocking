import React, { useState, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlus, faMinusSquare } from '@fortawesome/free-solid-svg-icons';
import { Link } from "react-router-dom";
import { db, storeage } from '../../firebase';
import setting from '../setting.json'; // setting[0].collection
import firebase from 'firebase';
import './AddItem.css';

function AddItem() {

    //input
    const [Name, setName] = useState("");
    const [Price, setPrice] = useState("");
    const [About, setAbout] = useState("");
    const [Brand, setBrand] = useState("");
    const [Catagory, setCatagory] = useState([]);
    // const [Weight, setWeight] = useState("");
    const [Status, setStatus] = useState("Publish");



    //avader file
    const [Avader, setAvader] = useState([]);
    const [Images, setImages] = useState([]);
    const [Progras, setProgras] = useState("");
    const [CurrentUplodingImage, setCurrentUplodingImage] = useState("0");

    //catagoryLists
    const [CatagoryLists, setCatagoryLists] = useState([]);

    //WeightOption
    const [WeightOptionList, setWeightOptionList] = useState([])
    const [WeightOption, setWeightOption] = useState("");
    const [WeightPrice, setWeightPrice] = useState("")

    //get the catagoye
    useEffect(() => {
        db.collection("category").orderBy('timestamp', 'desc').onSnapshot(snapshot => {
            const data = snapshot.docs.map(doc => {
                let id = doc.id;
                let data = doc.data();
                return { id, ...data }
            });
            setCatagoryLists(data);
        });
    }, []);


    //submit from
    const submitFunction = ((e) => {
        if (Name && About && Catagory) {

            if (Images.length !== 0) {

                const imagesUrl = []
                for (let i = 0; i < Images.length; i++) {
                    const image = Images[i];

                    // UPLOAD ALL THE FILES/IMAGES
                    const uploadTask = storeage.ref(`${setting[0].collection}/${image.name}`).put(image);
                    uploadTask.on(
                        "state_changed",
                        (snapshort) => {
                            const prograss = Math.round((snapshort.bytesTransferred / snapshort.totalBytes) * 100);
                            setProgras(prograss);
                        },
                        (error) => {
                            alert(error.message);
                        },
                        () => {
                            storeage.ref(setting[0].collection).child(image.name).getDownloadURL().then((url) => {
                                imagesUrl.push(url);
                                setProgras(0);
                                setCurrentUplodingImage(i + 1);

                                //IF UPLOAD ALL THE FILES/IMAGES ARE SUCCESSFULL
                                if (i == Images.length - 1) {
                                    db.collection(setting[0].collection).add({

                                        // price: parseInt(Price),
                                        // brand: Brand,
                                        // weight: Weight,
                                        // weightOption: WeightOptionList,


                                        name: Name,
                                        about: About,
                                        catagory: Catagory,
                                        status: Status,
                                        img: imagesUrl,
                                        timestamp: firebase.firestore.FieldValue.serverTimestamp(),
                                    }).then(() => {
                                        alert(`${setting[0].collection} has been added`);
                                        // setName("");
                                        // setPrice("");
                                        // setAbout("");
                                        // setBrand("");
                                        // setCatagory("");
                                        // setWeight("");
                                        // setStatus("false");
                                    });
                                }
                            });
                        }
                    );
                }

            } else {
                db.collection(setting[0].collection).add({
                    name: Name,
                    // price: parseInt(Price),
                    about: About,
                    // brand: Brand,
                    catagory: Catagory,
                    // weight: Weight,
                    // weightOption: WeightOptionList,
                    status: Status,
                    timestamp: firebase.firestore.FieldValue.serverTimestamp(),
                }).then(() => {
                    alert(`${setting[0].collection} has been added`);
                    // setName("");
                    // setPrice("");
                    // setAbout("");
                    // setBrand("");
                    // setCatagory("");
                    // setWeight("");
                    // setStatus("false");
                });
            }


        } else {
            console.log('please seet all the imput');
        }

        e.preventDefault();
    });


    //previw imagess
    const selectedFile = ((e) => {
        var file = document.getElementById('avader').files;

        const privewfileArray = [];
        const blobfileArray = [];
        for (let i = 0; i < file.length; i++) {
            const element = file[i];
            privewfileArray.push({ id: i, url: window.URL.createObjectURL(element) });
            blobfileArray.push(element);
        }

        setAvader(privewfileArray);
        setImages(blobfileArray);
    });

    const removeCatagoryItem = (e) => {
        setCatagory(Catagory.filter((v) => e != v ? v : null));
    }

    const removeWeightOption = (e) => {
        var filtered = WeightOptionList.filter(function (el) { return el.option != e; });
        setWeightOptionList(filtered);
    }

    return (
        <div className="AddItem">
            <form onSubmit={submitFunction} >
                {/* HEADER */}
                <div className="header">
                    <h1 style={{ margin: 0 }}>Add {setting[0].collection}</h1>
                    <Link to={`/${setting[0].collection}`}><FontAwesomeIcon icon={faMinusSquare} color="red" size="2x" /></Link>
                </div>


                {/* PRIVIWS */}
                <div className="privew">
                    <div className="addimage" onClick={() => { document.getElementById('avader').click() }}>
                        <FontAwesomeIcon icon={faPlus} color="black" size="3x" />
                        <input type="file" id="avader" onChange={selectedFile} style={{ display: 'none' }} multiple />
                    </div>
                    {Avader.map((e) => (<div key={e.id} style={{ backgroundImage: `url(${e.url})` }}></div>))}
                </div>

                {/* INPUTS */}
                <input type="text" onChange={(e) => (setName(e.target.value))} value={Name} placeholder="Title" />
                {/* <input type="number" onChange={(e) => (setPrice(e.target.value))} value={Price} placeholder="Price" />
                <input type="text" onChange={(e) => (setBrand(e.target.value))} value={Brand} placeholder="Brand" /> */}
                <textarea onChange={(e) => { setAbout(e.target.value) }} value={About} placeholder="News..." cols="30" rows="5"></textarea>
                {/* <label>
                    Weight:
                    <div className="WeightOptionView">
                        {
                            WeightOptionList.map((e) => (<p key={e}>

                                {e.option} = tk{e.price}
                                <span onClick={() => removeWeightOption(e.option)}>x</span>
                            </p>))
                        }
                    </div>
                    <div className="WeightOption">
                        <input type="text" onChange={(e) => (setWeightOption(e.target.value))} value={WeightOption} placeholder="option" />
                        <input type="number" onChange={(e) => (setWeightPrice(e.target.value))} value={WeightPrice} placeholder="price" />
                        <button style={{ fontSize: "18px" }} onClick={(e) => {
                            setWeightOptionList([...WeightOptionList, { option: WeightOption, price: WeightPrice }])
                            e.preventDefault();
                        }}>+</button>
                    </div>
                </label> */}
                <label>
                    Catagory:
                    <div className="catagorySpan">
                        {Catagory.map((e) => (<span key={e}>{e}<strong onClick={() => (removeCatagoryItem(e))}>x</strong></span>))}
                    </div>
                    <select  value={Catagory} onChange={(e) => (setCatagory([...Catagory, e.target.value]))}>
                        <option value="none">none</option>
                        {CatagoryLists.map((data) => (<option key={data.id} value={data.name}>{data.name}</option>))}
                    </select>
                </label>
                <label>
                    status:
                    <select value={Status} onChange={(e) => (setStatus(e.target.value))}>
                        <option value="Unpublish">Unpublish</option>
                        <option value="Publish">Publish</option>
                    </select>
                </label>


                {/* SUBMIT */}
                <input type="submit" value={`Add ${setting[0].collection}`} />

                {/* PROGRASS */}
                <div>
                    <span>{CurrentUplodingImage}/{Images.length}</span>
                    <progress style={{ display: "inline-block" }} id="file" value={Progras} max="100"> {`${Progras} %`} </progress>
                </div>
            </form>
        </div>
    )
}


export default AddItem;