import React, { useState, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheckSquare, faCoffee, faPlus, faMinusSquare } from '@fortawesome/free-solid-svg-icons'
import { useParams, Link } from "react-router-dom";
import { db } from '../../firebase';
import setting from '../setting.json'; // setting[0].collection
import './Viewstyle.css';

function View() {

    // Route paramiter
    const { id } = useParams();

    //inputs
    const [Name, setName] = useState("");
    const [Price, setPrice] = useState("");
    const [About, setAbout] = useState("");
    const [Brand, setBrand] = useState("");
    const [Catagory, setCatagory] = useState("");
    const [Weight, setWeight] = useState("");
    const [Images, setImages] = useState([]);


    useEffect(() => {
        db.collection(setting[0].collection).doc(id).get().then((e) => {
            const item = e.data();
            setName(item.name);
            setPrice(item.price);
            setAbout(item.about);
            setBrand(item.brand);
            setCatagory(item.catagory);
            setWeight(item.weight);
            setImages(item.img);
        });
    }, []);


    return (
        <div className="View">
            <div className="view-section">
                <div className="header">
                    <h1 style={{margin: 0}}>this is Viw item</h1>
                    <Link to={`/${setting[0].collection}`}><FontAwesomeIcon icon={faMinusSquare} color="red" size="2x" /></Link>
                </div>

                <hr />

                <div className="images">
                    {Images? Images.map((img) => (<img key={img} src={img} />)): <h1>no images</h1>}
                </div>

                <div className="info">
                    <p><strong>Name: </strong>{Name}</p>
                    <p><strong>Price: </strong>{Price}</p>
                    <p><strong>About: </strong>{About}</p>
                    <p><strong>Brand: </strong>{Brand}</p>
                    <p><strong>Catagory: </strong>{Catagory}</p>
                    <p><strong>Weight: </strong>{Weight}</p>
                </div>

            </div>
        </div>
    )
}

export default View
