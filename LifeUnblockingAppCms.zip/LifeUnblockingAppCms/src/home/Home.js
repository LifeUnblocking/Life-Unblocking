import React, { useState, useEffect } from 'react';
import './Home.css'
import { auth, db } from '../firebase';

function Home() {

    const [Email, setEmail] = useState("");
    const [Password, setPassword] = useState("");
    const [CurrentUserEmail, setCurrentUserEmail] = useState("");
    const [CurrentUserID, setCurrentUserID] = useState("");

    // app setting
    const [MinPrice, setMinPrice] = useState("")
    const [MaxPrice, setMaxPrice] = useState("")
    const [ShippingText, setShippingText] = useState("")
    const [CartPolicyText, setCartPolicyText] = useState("")
    const [OrderConfirmationText, setOrderConfirmationText] = useState("")
    const [AgrryButtonText, setAgrryButtonText] = useState("")

    const login = (email, password) => {
        auth.signInWithEmailAndPassword(email, password).then(() => {
            alert('login successfull');
        }).catch(function (error) {
            // Handle Errors here.
            var errorCode = error.code;
            var errorMessage = error.message;
            // ...
        });
    }

    useEffect(() => {
        auth.onAuthStateChanged(function (user) {
            if (user) {
                // User is signed in.
                setCurrentUserEmail(user.email);
                setCurrentUserID(user.uid);
            } else {
                setCurrentUserEmail("");
                setCurrentUserID("");
            }
        });

        db.collection("appSetting").doc("App")
            .get().then((app) => {
                // setMaxPrice(app.data().maxPrice)
                // setMinPrice(app.data().minPrice)
                // setAgrryButtonText(app.data().agrryButton)
                // setOrderConfirmationText(app.data().orderConfirmationText)
                // setCartPolicyText(app.data().policy)
                // setShippingText(app.data().shipping)
            });

    }, [])



    // SAVE SETTING 
    const saveSetting = () => {
        db.collection("appSetting").doc("App")
            .set({
                minPrice: MinPrice,
                maxPrice: MaxPrice,
                agrryButton: AgrryButtonText,
                orderConfirmationText: OrderConfirmationText,
                policy: CartPolicyText,
                shipping: ShippingText,
            }).then(() => { alert('setting has been save') });
    }

    return (
        <div className="home">

            <div className="head">
                <div>
                    <h1>Home Screen</h1>
                </div>
                <div>
                    {!CurrentUserEmail ?
                        <div className="login-area">
                            <input onChange={(e) => (setEmail(e.target.value))} value={Email} type="Email" placeholder="Email" />
                            <input onChange={(e) => (setPassword(e.target.value))} value={Password} type="password" placeholder="password" />
                            <button disabled={Email.empty && Password.empty} onClick={(e) => login(Email, Password)}>login</button>
                        </div>
                        : <div className="current-user">
                            <h3>Admin user</h3>
                            <p>{CurrentUserEmail}</p>
                            <p>{CurrentUserID}</p>
                            <button onClick={() => auth.signOut().then(function () {
                                alert('user goon')
                            }).catch(function (error) {
                                alert('here is an error' + error.message)
                            })}>log Out</button>
                        </div>
                    }
                </div>
            </div>
            <hr />
            <h1>WELCOM TO YOUR CMS</h1>
            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores ratione totam nesciunt qui soluta consequatur esse voluptatem nostrum eligendi accusantium, commodi est sequi, porro neque itaque veritatis eos, cupiditate voluptatum.
            </p>
            {/* <h3>app setting</h3>
            <span>min price</span> <br />
            <input onChange={(e) => (setMinPrice(parseInt(e.target.value)))} value={MinPrice} type="number" /> TK
            <hr />
            <span>max price</span><br />
            <input onChange={(e) => (setMaxPrice(parseInt(e.target.value)))} value={MaxPrice} type="number" /> TK
            <hr />
            <span>ShippingText</span><br />
            <textarea onChange={(e) => (setShippingText(e.target.value))} value={ShippingText} cols="60" rows="3"></textarea><br />
            <hr />
            <span>CartPolicyText</span><br />
            <textarea onChange={(e) => (setCartPolicyText(e.target.value))} value={CartPolicyText} cols="60" rows="3"></textarea><br />
            <hr />
            <span>OrderConfirmationText</span><br />
            <textarea onChange={(e) => (setOrderConfirmationText(e.target.value))} value={OrderConfirmationText} cols="60" rows="3"></textarea><br />
            <span>AgrryButtonText</span><br />
            <textarea onChange={(e) => (setAgrryButtonText(e.target.value))} value={AgrryButtonText} cols="60" rows="3"></textarea><br />

            <button onClick={() => saveSetting()}>Save</button> */}

        </div>
    )
}

export default Home
