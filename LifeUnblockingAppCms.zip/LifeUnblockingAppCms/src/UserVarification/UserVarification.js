import React from 'react'

function UserVarification() {
    return (
        <div>
            <h1>User Varification</h1>
        </div>
    )
}

export default UserVarification
