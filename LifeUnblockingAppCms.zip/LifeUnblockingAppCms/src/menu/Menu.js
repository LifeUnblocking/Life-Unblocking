import React from 'react'
import './Menu.css'
import { Link, NavLink } from 'react-router-dom'

export default function Menu() {
    return (
        <div className="Menu">
            <ul>
                <li><NavLink exact={true} activeClassName='is-active' to="/">home</NavLink></li>
                {/* <li><NavLink activeClassName='is-active' to="/orders">Orders</NavLink></li> */}
                <li><NavLink activeClassName='is-active' to="/users">Users</NavLink></li>
                <li><NavLink activeClassName='is-active' to="/category">News Category</NavLink></li>
                <li><NavLink activeClassName='is-active' to="/news">News Postes</NavLink></li>
            </ul>
        </div>
    )
}
