# CycleSafeUK created using a Blank PhoneGap App


## About
This was originally devleloped as a starting point for the development of a 'final year project'.

The idea is that the app will provide the learning basis for creating a cycling navigation application using PhoneGap/Cordova. The concept app is meant to provide basic form validation with Cloud Firebase data management. 

As this module is for 15 credits, the original intended scope was scalled back to remove some advanced functionality like device light API, and push notifications. Some of these features will be developed along with more substantial content for the final assignment.


###Details
The following Paid APIs:
Google maps
Elevation
Bike
Drive
Walk

### Database
Created using FireBase data management. 


## Usage
This template was created originally using 'Hello Cordova' generic app. The main reason was due to starting  with a fresh template instead of using online templates that could cause confusion later on.

### PhoneGap CLI

    $ phonegap create my-app --template blank
    
   

### Desktop

In your browser, open the file:

    /www/index.html


### Repository
https://dev.azure.com/kg15abr0276/CycleSafeUK



