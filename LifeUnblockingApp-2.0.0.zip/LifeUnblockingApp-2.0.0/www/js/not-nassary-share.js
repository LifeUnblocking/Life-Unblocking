$(document).delegate("#sharePage", "pageinit", function () {

    var message = 'Life Unblocking APP is a Beautiful App';
    var title = 'Life Unblocking';
    var img = 'https://i.ibb.co/f98TqPr/Logo-App.png';
    var url = 'https://twitter.com/lifeunblocking'; //it will replace when with playstore link

    $('#Facebook').on('click', function () {
        window.plugins.socialsharing.shareViaFacebook(
            message,
            img /* img */ ,
            url /* url */ ,
            function () {
                console.log('share ok')
            },
            function (errormsg) {
                alert(errormsg)
            })
    });
    $('#Twitter').on('click', function () {
        window.plugins.socialsharing.shareViaTwitter(
            message,
            img /* img */ ,
            url /* url */ ,
            function () {
                console.log('share ok')
            },
            function (errormsg) {
                alert(errormsg)
            })
    });
    $('#Instagram').on('click', function () {
        window.plugins.socialsharing.shareViaInstagram(
            message,
            img /* img */ ,
            function () {
                console.log('share ok')
            },
            function (errormsg) {
                alert(errormsg)
            })
    });
    $('#Other').on('click', function () {
        window.plugins.socialsharing.share(message, title, img, url)
    });

});