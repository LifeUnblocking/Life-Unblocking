$(document).delegate("#articaPage", "pageinit", function () {

    var db = firebase.firestore();

    //get all the gatagory
    db.collection("category").get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            var option = `<option value="${doc.data().name}">${doc.data().name}</option>`;
            $('#select-native-3').append(option)
            $('#select-native-3').selectmenu("refresh", true);
        });
    });

    //get all the postes
    getAllThePostes()

    function getAllThePostes() {
        db.collection("news").get()
            .then((querySnapshot) => {
                querySnapshot.forEach((doc) => {

                    var container = `
                    <div class="container">
                        <div class="responsive-image" style="background:url('${doc.data().img[0]}')">
                            <span class="catagory-span">${doc.data().catagory}</span>
                        </div>
                        <h4 class="uppercase bold text-shadow">${doc.data().name}</h4>
                        <p class="text-shadow" style="margin-bottom: 10px;">
                            ${(doc.data().about.length > 100)?doc.data().about.substring(0,100):doc.data().about}...
                        </p>
                        <a href="articleSingle.html?id=${doc.id}" class="ui-btn button3">More</a>
                    </div>
                    `
                    $('.portfolio-single').append(container);
                });
            })
            .catch((error) => {
                console.log("Error getting documents: ", error);
            });
    }

    //get catagory postes
    $('#select-native-3').on('change', function () {
        $('.portfolio-single').empty();
        if (this.value == 'all') {
            getAllThePostes();
        } else
            db.collection("articles").where("category", "array-contains", this.value).get()
            .then((querySnapshot) => {
                querySnapshot.forEach((doc) => {
                    var container = `
                <div class="container">
                    <div class="responsive-image" style="background:url('${doc.data().image[0].downloadURL}')">
                        <span class="catagory-span">${doc.data().category}</span>
                    </div>
                    <h4 class="uppercase bold text-shadow">${doc.data().title}</h4>
                    <p class="text-shadow" style="margin-bottom: 10px;">
                        ${(doc.data().body.length > 100)?doc.data().body.substring(0,100):doc.data().body}...
                    </p>
                    <a href="singleArticle.html?id=${doc.id}" class="ui-btn button3">More</a>
                </div>
                `
                    $('.portfolio-single').append(container);
                });
            })
            .catch((error) => {
                console.log("Error getting documents: ", error);
            });
    });


    var isclicked = false;
    $('.seacchbutton').on('click', function() {
        if(isclicked){
            $('.articalTitle').hide()
            $('.articalSearch').show()
            isclicked = !isclicked
        }else{

            $('.articalTitle').show()
            $('.articalSearch').hide()

            isclicked = !isclicked
        }
    })



});