document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady() {

    // getDynamicLink
    // Determines if the app has a pending dynamic link and provide access to the dynamic link parameters.
    //------------------------------------------------------------------------------------
    // cordova.plugins.firebase.dynamiclinks.getDynamicLink().then(function (data) {
    //     if (data) {
    //         console.log("Read dynamic link data on app start:", data);
    //     } else {
    //         console.log("App wasn't started from a dynamic link");
    //     }
    // });

    // onDynamicLink(callback)
    // Registers callback that is triggered on each dynamic link click.
    //------------------------------------------------------------------------------------
    cordova.plugins.firebase.dynamiclinks.onDynamicLink(function (data) {
        // The client SDK will parse the code from the link for you.
        var userDataForRegistration = JSON.parse(window.localStorage.getItem('userDataForRegistration'));
        firebase.auth().signInWithEmailLink(userDataForRegistration.email, data.deepLink)
            .then((result) => {
                var currentUserID = result.user.uid;
                firebase.firestore().collection('users').doc(currentUserID).set({
                    name: userDataForRegistration.fullName,
                    phone: userDataForRegistration.phone,
                    email: userDataForRegistration.email,
                    user: currentUserID,
                    timestamp: firebase.firestore.FieldValue.serverTimestamp(),
                }).then(() => {
                    window.localStorage.removeItem('userDataForRegistration');
                });
            })
            .catch((error) => {
                alert(error)
            });
    });
}