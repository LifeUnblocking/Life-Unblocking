function doValidforRegister(fullName, email, phone, checkedBox){

    //form validation
    var err = [];
    
    if ( fullName == "" ) {
        err.push("FullName is required");
        $('#regi-fullName').addClass('errorStyle');
        $('.ValidationText.regiName').show();
    }else{
        $('#regi-fullName').removeClass('errorStyle');
        $('.ValidationText.regiName').hide();
    }

    if ( email == "" ) {
        err.push("Email is required");
        $('#regi-email').addClass('errorStyle');
        $('.ValidationText.regiEmail').show();
    }else{
        $('#regi-email').removeClass('errorStyle');
        $('.ValidationText.regiEmail').hide();
    }

    if ( phone == "" ) {
        err.push("Phone is required");
        $('#regi-phone').addClass('errorStyle');
        $('.ValidationText.regiPhone').show();
    }else{
        $('#regi-phone').removeClass('errorStyle');
        $('.ValidationText.regiPhone').hide();
    }

    // if ( password == "" ) {
    //     err.push("Password is required");
    //     $('.regiPasswordInput').addClass('errorStyle');
    //     $('.ValidationText.regiPassword').show();
    // }else{
    //     $('.regiPasswordInput').removeClass('errorStyle');
    //     $('.ValidationText.regiPassword').hide();
    // }

    // if ( confPassword == "" ) {
    //     err.push("Confirm Password is required");
    //     $('#regi-conf-password').addClass('errorStyle');
    //     $('.ValidationText.regiConfirmPassword').show();
    // }else{
    //     $('#regi-conf-password').removeClass('errorStyle');
    //     $('.ValidationText.regiConfirmPassword').hide();
    // }

    // if ( password != confPassword ) {
    //     err.push("passwords do not match");
    //     $('#regi-conf-password').addClass('errorStyle');
    //     $('#regi-password').addClass('errorStyle');
    //     $('.ValidationText.notMatch').show();
    // }else{
    //     $('#regi-conf-password').removeClass('errorStyle');
    //     $('#regi-password').removeClass('errorStyle');
    //     $('.ValidationText.notMatch').hide();
    // }

    if ( checkedBox != true ) {
        err.push("Read Our PRIVACY first");
        $('.privacy-stetment-checkbox').addClass('errorStyle');
        $('.ValidationText.PRIVACY').show();
    }else{
        $('.privacy-stetment-checkbox').removeClass('errorStyle');
        $('.ValidationText.PRIVACY').hide();
    }

    return err;
}



function doValidforLogin(email, password){
    var err = [];


    if ( email == "" ) {
        err.push("Email is required");
        $('#loginEmail').addClass('errorStyle');
        $('.ValidationText.logeEmail').show();
        
    }else{
        $('#loginEmail').removeClass('errorStyle');
        $('.ValidationText.logeEmail').hide();
    }


    if ( password == "" ) {
        err.push("Password is required");
        $('#loginPassword').addClass('errorStyle');
        $('.ValidationText.logePassword').show();
    }else{
        $('#loginPassword').removeClass('errorStyle');
        $('.ValidationText.logePassword').hide();
    }

    return err;
}



function doValidforjourneyPostForm(selectChoiceAs, journeyOrigin, journeyDestination, journeyDate, journeyTime, journeyFurtherInstruction){
    // form validation
    var err = [];
    if ( selectChoiceAs == "0" ) {
        err.push("you must be choice driver or pessenger");
    }
    if ( journeyOrigin == "" ) {
        err.push("Origin must be filled out");
        $('#journey-origin').attr('class', 'errorStyle');
    }
    if ( journeyDestination == "" ) {
        err.push("Destination must be filled out");
        $('#journey-destination').attr('class', 'errorStyle');
    }
    if ( journeyDate == "" ) {
        err.push("Date must be filled out");
        $('#journey-date').attr('class', 'errorStyle');
    }
    if ( journeyTime == "" ) {
        err.push("Time must be filled out");
        $('#journey-time').attr('class', 'errorStyle');
    }
    if ( journeyFurtherInstruction == "" ) {
        err.push("Time must be filled out");
        $('#journey-furtherInstruction').attr('class', 'errorStyle');
    }

    return err;
}