// document.addEventListener("deviceready", onDeviceReady, false);
$(document).ready(onDeviceReady)

function onDeviceReady() {

    //-----------------------------------------
    //            Index Page Init
    //-----------------------------------------
    $(document).delegate("#indexPage", "pageinit", function () {

        // $('.shareButton').on('click',  function() {
        //     console.log('adfasd')
        //     $('#shareSelectionLinks').click();
        // });
    });

    //-----------------------------------------------------------
    //      event if user is SignedIn or Signed SignedOut
    //-----------------------------------------------------------
    var currentUserID;
    firebase.auth().onAuthStateChanged(function (user) {
        if (user) {
            // User is signed in.
            var displayName = user.displayName;
            var email = user.email;
            var emailVerified = user.emailVerified;
            var photoURL = user.photoURL;
            var isAnonymous = user.isAnonymous;
            currentUserID = user.uid;
            var providerData = user.providerData;
            //------------------------------------------
            //      check user connection status
            //------------------------------------------
            var myConnectionsRef = firebase.database().ref("MapUsers/" + currentUserID + "/connections");
            var lastOnlineRef = firebase.database().ref("MapUsers/" + currentUserID + "/lastOnline");
            var connectedRef = firebase.database().ref('.info/connected');
            connectedRef.on('value', function (snap) {
                if (snap.val() === true) {
                    var con = myConnectionsRef.push();
                    con.onDisconnect().remove();
                    con.set(true);
                    lastOnlineRef.onDisconnect().set(firebase.database.ServerValue.TIMESTAMP);
                }
            });

        }
    });


    //-----------------------------------------
    //           preloader effect
    //-----------------------------------------
    $(document).on('pagebeforecreate', '[data-role="page"]', function () {
        var interval = setInterval(function () {
            $.mobile.loading('show');
            clearInterval(interval);
        }, 1);
    });
    $(document).on('pageshow', '[data-role="page"]', function () {
        var interval = setInterval(function () {
            $.mobile.loading('hide');
            clearInterval(interval);
        }, 300);
    });


};