$(document).on("pageinit", "#singlePage", function (event) {
    var parameters = $(this).data("url").split("?")[1];
    var parameter = parameters.replace("id=", "");

    var db = firebase.firestore();

    var docRef = db.collection("news").doc(parameter);

    docRef.get().then((doc) => {
        if (doc.exists) {
            // ${image.downloadURL}
            // <div clase='reimg' style="background: url('${image.downloadURL}')"></div>
            // if(doc.data().image.length !== 1){
            //     alert('korim')
            //     $('#imagesScetion img').css()
            // }

            for (const image of doc.data().img) {
                var imagSection = `
                    <img style="${doc.data().img.length !== 1? 'max-width: 49%;':''}" src="${image}">
                `
                $('#imagesScetion').append(imagSection);
            }

            var container = `
            <div class="container">
                <h2 class="uppercase bold text-shadow section-title2">${doc.data().name}</h2>
                <hr class="divider">
                <p class="text-shadow">${doc.data().about}</p>
            </div>
            `
            $('.single-articale').append(container);
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });




    $(document).on('click', '#imagesScetion img', function() {
        console.log(this.src)

        $( "#popupParis img" ).attr('src', this.src); 
        $( "#popupParis" ).popup( "open" ); 
    })
   


});