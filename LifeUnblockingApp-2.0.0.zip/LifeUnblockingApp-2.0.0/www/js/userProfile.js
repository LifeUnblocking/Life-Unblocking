//------------------------------------------
//      User Profile page
//------------------------------------------
$(document).delegate("#userProfilePage", "pageinit", function () {
    var currentUserID;
    firebase.auth().onAuthStateChanged(function (user) {
        if (user) {
            // User is signed in.
            var displayName = user.displayName;
            var email = user.email;
            var emailVerified = user.emailVerified;
            var photoURL = user.photoURL;
            var isAnonymous = user.isAnonymous;
            currentUserID = user.uid;
            var providerData = user.providerData;

            //get user data from firebase database
            //-----------------------------------------
            // firebase.database().ref("MapUsers/" + currentUserID + "/userInfo").on('value', (snapshot) => {
            //     const data = snapshot.val();
            //     $('.userName').text(data.fullName);
            //     $('.userNameInput').val(data.fullName);
            //     $('.userEmail').text(data.email);

            //     if (data.photoURL) {
            //         $('.profile-section .userImage').css('background', `url('${data.photoURL}')`);
            //     }
            // });

            firebase.firestore().collection('users').doc(currentUserID).onSnapshot((snap) => {
                var data = snap.data();
                $('.userName').text(data.name);
                $('.userNameInput').val(data.name);
                $('.userEmail').text(data.email);

                if (data.photoURL) {
                    $('.profile-section .userImage').css('background', `url('${data.photoURL}')`);
                }
            });
        }
    });


    //------------------------------------------------      
    //set online status
    //-------------------------------------------------
    // $("#UserOnlineStatus").on("change", function (e) {
    //     var option = $('#UserOnlineStatus').val();
    //     if (option == "true") {

    //     }
    //     var currentUserID = firebase.auth().currentUser.uid;
    //     firebase.database().ref("MapUsers/" + currentUserID).update({
    //         onlineStatus: option
    //     }).then(() => {
    //         localStorage.setItem("UserOnlineStatus", option);
    //     });
    // });
    // if (localStorage.UserOnlineStatus != undefined) {
    //     $('#UserOnlineStatus').val(localStorage.UserOnlineStatus).slider('refresh');
    // }

    //------------------------------------------
    //              logOut Event
    //------------------------------------------
    $('.exitButton').on('click', function () {
        firebase.auth().signOut();
    });

});


//------------------------------------------
//      User Edit Page
//------------------------------------------
$(document).delegate("#userEditPage", "pageinit", function () {
    var currentUserID;
    firebase.auth().onAuthStateChanged(function (user) {
        if (user) {
            // User is signed in.
            var displayName = user.displayName;
            var email = user.email;
            var emailVerified = user.emailVerified;
            var photoURL = user.photoURL;
            var isAnonymous = user.isAnonymous;
            currentUserID = user.uid;
            var providerData = user.providerData;


            //get user data from firebase database
            //-----------------------------------------
            // firebase.database().ref("MapUsers/" + currentUserID + "/userInfo").on('value', (snapshot) => {
            //     const data = snapshot.val();
            //     $('.userName').text(data.fullName);
            //     $('.userNameInput').val(data.fullName);
            //     $('.userEmail').text(data.email);

            //     if (data.photoURL) {
            //         $('.profile-section .userImage').css('background', `url('${data.photoURL}')`);
            //     }
            // });

            firebase.firestore().collection('users').doc(currentUserID).onSnapshot((snap) => {
                var data = snap.data();
                $('.userName').text(data.name);
                $('.userNameInput').val(data.name);
                $('.userEmail').text(data.email);

                if (data.photoURL) {
                    $('.profile-section .userImage').css('background', `url('${data.photoURL}')`);
                }
            });
        }
    });


    //------------------------------------------
    //              update user
    //------------------------------------------
    var dataurlFrofile;
    $("#updateProfileImage").on('change', function () {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("updateProfileImage").files[0]);
        oFReader.onload = function (oFREvent) {
            $('.uploadPreview').css('background', `url('${oFREvent.target.result}')`);
            dataurlFrofile = oFREvent.target.result;
        };
    })

    $("#updateUser").on("click", function () {

        var fullName = $("#updateFullName").val();

        // update name
        if (fullName != '') {
            var currentUserID = firebase.auth().currentUser.uid;
            // firebase.database().ref("MapUsers/" + currentUserID + "/userInfo").update({
            //     fullName: fullName,
            // });

            firebase.firestore().collection('users').doc(currentUserID).update({
                name: fullName,
            })
        }


        //update profile
        if (dataurlFrofile != undefined) {

            var storageRef = firebase.storage().ref();
            var uniqid = Date.now() + '.jpg';

            var uploadTask = storageRef.child('galleryImages/' + uniqid).putString(dataurlFrofile, 'data_url')
            uploadTask.on('state_changed', function (snapshot) {
                var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                console.log('Upload is ' + progress + '% done');
                $('.uplodinPrograss').show();
                $('.uplodinPrograss #progress').val(progress);
                switch (snapshot.state) {
                    case firebase.storage.TaskState.PAUSED: // or 'paused'
                        console.log('Upload is paused');
                        break;
                    case firebase.storage.TaskState.RUNNING: // or 'running'
                        console.log('Upload is running');
                        break;
                }
            }, function (error) {
                alert(error)
            }, function () {
                uploadTask.snapshot.ref.getDownloadURL().then(function (downloadURL) {
                    $('.uplodinPrograss').hide();
                    var currentUserID = firebase.auth().currentUser.uid;
                    // firebase.database().ref("MapUsers/" + currentUserID + "/userInfo").update({
                    //     photoURL: downloadURL,
                    // });
                    firebase.firestore().collection('users').doc(currentUserID).update({
                        photoURL: downloadURL,
                    })

                });

            });
        }

    });

});