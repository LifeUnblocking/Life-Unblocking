$(document).delegate("#musicPage", "pageinit", function () {


    var isPlay = false;
    var x = document.getElementById("myAudio");

    $('.playIcon').on('click', function () {
        if (!isPlay) {
            playSound(x);
        } else {
            pauseSound(x)
        }
    });

    $('.reloadIcon').on('click', function () {
        stopSound(x); //stop
        playSound(x);
    });

    x.onended = function () {
        pauseSound(x)
    };

    function stopSound(x) {
        x.pause();
        x.currentTime = 0;
    }

    
    function playSound(x) {
        isPlay = true;
        x.play();
        $('#musicImageDanc').attr('src', 'images/play.gif');
        $('.playIcon i').attr('class', 'fa fa-pause');
        $('.playIcon').addClass('buttonEffect');
    }
    function pauseSound(x) {
        isPlay = false;
        x.pause();
        $('#musicImageDanc').attr('src', 'images/pause.png');
        $('.playIcon i').attr('class', 'fa fa-play');
        $('.playIcon').removeClass('buttonEffect');
    }

});