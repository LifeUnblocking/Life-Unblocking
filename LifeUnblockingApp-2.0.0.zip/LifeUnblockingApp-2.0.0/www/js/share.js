$(document).delegate("#sharePage", "pageinit", function () {

    var message = `Life Unblocking tranformed my life. Learn more about how it can hekp you!! www.RemoveYourBlockages.com.
    Life Unblocking transformó mi vida. Aprenda más sobre cómo puede ayudarle! www.RemueveTusBloqueos.com.
    Life Unblocking tranformou a minha vida. Saiba mais sobre como o desbloqueio pode ajudar! www.RemoveYourBlockages.com.
    Life Unblocking 改变了我的生活。了解更多关于它如何能帮助你！！www.RemoveYourBlockages.com。
    Life Unblocking ha trasformato la mia vita. Scoprite di più su come può aiutarvi! www.RemoveYourBlockages.com.
    Life Unblocking a transformé ma vie. Apprenez-en plus sur la façon dont il peut vous aider ! www.RemoveYourBlockages.com.
    `;

    var title = 'Life Unblocking';
    var img = 'https://i.ibb.co/WgwZLJT/rounded-vertical-logo.png';
    var url = 'https://www.removeyourblockages.com/app';

    $('#Facebook').on('click', function () {
        window.plugins.socialsharing.shareViaFacebook(
            message,
            img /* img */ ,
            url /* url */ ,
            function () {
                console.log('share ok')
            },
            function (errormsg) {
                alert(errormsg)
            })
    });
    $('#Twitter').on('click', function () {
        window.plugins.socialsharing.shareViaTwitter(
            message,
            img /* img */ ,
            url /* url */ ,
            function () {
                console.log('share ok')
            },
            function (errormsg) {
                alert(errormsg)
            })
    });
    $('#Instagram').on('click', function () {
        window.plugins.socialsharing.shareViaInstagram(
            message,
            img /* img */ ,
            function () {
                console.log('share ok')
            },
            function (errormsg) {
                alert(errormsg)
            })
    });
    $('#Other').on('click', function () {
        window.plugins.socialsharing.share(message, title, img, url)
    });

});