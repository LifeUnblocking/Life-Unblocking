$(document).ready(function () {

    //------------------------------------------
    //              signin
    //------------------------------------------
    // $(document).on("click", "#signin", function () {
    //     var email = $("#loginEmail").val(),
    //         password = $("#loginPassword").val();
    //     // do validation for login from validation.js
    //     var err = doValidforLogin(email, password);
    //     if (err.length == 0) { //if no error in form
    //         firebase.auth().signInWithEmailAndPassword(email, password)
    //             .then(function () {
    //                 // $('.userName').text(displayName);
    //                 // $('.userEmail').text(email);
    //                 // if (photoURL != null) {
    //                 //     $('.userImage').css('background', `url('${photoURL}')`);
    //                 // }
    //                 // $('.userNameInput').val(displayName);
    //                 // $('.userEmailInput').val(email);
    //                 $('#LoginPage input').val('');
    //             })
    //             .catch(function (error) {
    //                 // Handle Errors here.
    //                 var errorCode = error.code;
    //                 var errorMessage = error.message;
    //                 alert(errorMessage);
    //                 // ...
    //             });
    //     } else {
    //         console.log('all inputs are required');
    //     }
    // });



    //------------------------------------------
    //              register
    //------------------------------------------
    $(document).on("click", "#register", function () {

        var fullName = $("#regi-fullName").val(),
            email = $("#regi-email").val(),
            phone = $("#regi-phone").val(),
            checkedBox = $("#checkbox-enhanced").is(":checked");

        // do validation for register from validation.js
        var err = doValidforRegister(fullName, email, phone, checkedBox);
        if (err.length == 0) { //if no form error

            var actionCodeSettings = {
                // URL you want to redirect back to. The domain (www.example.com) for this
                // URL must be in the authorized domains list in the Firebase Console.
                url: 'https://life-unblocking.firebaseapp.com/',
                // This must be true.
                handleCodeInApp: true,
                iOS: {
                    bundleId: 'com.abkorim.LifeUnblocking'
                },
                android: {
                    packageName: 'com.abkorim.LifeUnblocking',
                    installApp: true,
                    minimumVersion: '12'
                },
                dynamicLinkDomain: 'userverify.page.link'
            }

            firebase.auth().sendSignInLinkToEmail(email, actionCodeSettings)
                .then(() => {

                    //set user data to localstorage
                    var userDataForRegistration = JSON.stringify({
                        phone: phone,
                        email: email,
                        fullName: fullName,
                    });
                    window.localStorage.setItem('userDataForRegistration', userDataForRegistration);

                    //navigate user to 
                    $.mobile.navigate("EmailVarification.html", {
                        transition: "pop"
                    });
                })
                .catch((error) => {
                    var errorCode = error.code;
                    var errorMessage = error.message;
                    alert(error);
                });

        } else {
            console.log('all inputs are required');
        }
    });

    //abGoToRegister
    $(document).on('click', '#abGoToRegister', function () {
        $.mobile.changePage("register.html", {
            transition: "pop",
            reverse: true,
            changeHash: false,
        });
    })

    //abGoToLogin
    $(document).on('click', '#abGoToLogin', function () {
        $.mobile.changePage("login.html", {
            transition: "pop",
            reverse: true,
            changeHash: false,
        });
    })
});