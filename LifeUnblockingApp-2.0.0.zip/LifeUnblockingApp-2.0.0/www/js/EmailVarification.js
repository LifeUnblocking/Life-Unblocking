//------------------------------------------
//      Email Varification
//------------------------------------------
$(document).delegate("#EmailVarification", "pageinit", function () {

    //set saved email
    var userDataForRegistration = JSON.parse(window.localStorage.getItem('userDataForRegistration'));
    if (userDataForRegistration) {
        $('.savedEmail').text(`(${userDataForRegistration.email})`)
    } else {
        $('.savedEmail').text('(your email)')
    }


    //------------------------------------------
    //           Email Verify Button
    //------------------------------------------
    $('#SendEmailAgainButton').on('click', function () {

        var actionCodeSettings = {
            // URL you want to redirect back to. The domain (www.example.com) for this
            // URL must be in the authorized domains list in the Firebase Console.
            url: 'https://life-unblocking.firebaseapp.com/',
            // This must be true.
            handleCodeInApp: true,
            iOS: {
                bundleId: 'com.abkorim.LifeUnblocking'
            },
            android: {
                packageName: 'com.abkorim.LifeUnblocking',
                installApp: true,
                minimumVersion: '12'
            },
            dynamicLinkDomain: 'userverify.page.link'
        }

        firebase.auth().sendSignInLinkToEmail(userDataForRegistration.email, actionCodeSettings)
            .then(() => {
                console.log('done')
            })
            .catch((error) => {
                var errorCode = error.code;
                var errorMessage = error.message;
                alert(error);
            });


    });

});