// document.addEventListener("deviceready", onDeviceReady, false);
// $(document).on("pagecreate", "#mapScreen", onDeviceReady);
$(document).ready(function () {
    $(document).delegate("#mapScreen", "pageinit", onDeviceReady);

    function onDeviceReady() {



        // CHECK LOCATION PIRMISION
        cordova.plugins.diagnostic.requestLocationAuthorization(function (status) {
            switch (status) {
                case cordova.plugins.diagnostic.permissionStatus.NOT_REQUESTED:
                    console.log("Permission not requested");
                    break;
                case cordova.plugins.diagnostic.permissionStatus.GRANTED:
                    console.log("Permission granted");
                    mapInit();
                    break;
                case cordova.plugins.diagnostic.permissionStatus.DENIED:
                    console.log("Permission denied");
                    $.mobile.navigate( "./parmition.html" );
                    
                    break;
                case cordova.plugins.diagnostic.permissionStatus.DENIED_ALWAYS:
                    console.log("Permission permanently denied");
                    $.mobile.navigate( "./parmition.html" );
                    break;
            }
        }, function (error) {
            console.error(error);
        });


        // MAP INIT
        // Get the latitude and the longitude;
        function mapInit(){
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function (position) {
                    var lat = position.coords.latitude;
                    var lng = position.coords.longitude;
                    codeLatLng(parseFloat(lat), parseFloat(lng))
    
                }, function (error) {
                    console.log('code: ' + error.code + '\n' +
                        'message: ' + error.message + '\n');
                }, {
                    maximumAge: 500000,
                    timeout: 6000,
                    enableHighAccuracy: true
                });
            } else {
                alert('geolocation not suported');
            }
        }

        var markers = []; //FOR RELOADING THE MARKERS
        var map;

        function codeLatLng(lat, lng) {

            //ADDING MAP 
            //---------------------------------------------------------------
            map = new google.maps.Map(
                document.getElementById('map'), {
                    zoom: 15,
                    center: new google.maps.LatLng(lat, lng),
                    mapTypeControlOptions: {
                        style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR,
                        position: google.maps.ControlPosition.TOP_CENTER,
                    },
                }
            );


            //CyclingLayer
            //----------------------------------------------------------------
            const bikeLayer = new google.maps.BicyclingLayer();
            bikeLayer.setMap(map);


            // DIRACTION
            //----------------------------------------------------------------
            const directionsService = new google.maps.DirectionsService();
            const directionsRenderer = new google.maps.DirectionsRenderer({
                map,
                draggable: true,
                panel: document.getElementById("right-panel"),
            });
            directionsRenderer.addListener("directions_changed", () => {
                computeTotalDistance(directionsRenderer.getDirections());
            });


            function displayRoute(destination, selectedMode) {
                directionsService.route({
                        origin: new google.maps.LatLng(lat, lng),
                        destination: destination,
                        travelMode: selectedMode ? google.maps.TravelMode[selectedMode] : google.maps.TravelMode.BICYCLING,
                        avoidTolls: true,
                    },
                    (result, status) => {
                        if (status === "OK") {
                            directionsRenderer.setDirections(result);
                            $('#summaryab').show();
                        } else {
                            alert("Directions not found");
                        }
                    }
                );
            }

            function computeTotalDistance(result) {
                let total = 0;
                const myroute = result.routes[0];
                for (let i = 0; i < myroute.legs.length; i++) {
                    total += myroute.legs[i].distance.value;
                }
                total = total / 1000;
                // document.getElementById("total").innerHTML = total + " km";
                // console.log(myroute)
                // console.log(myroute.legs[0].distance.text);
                // console.log(myroute.legs[0].duration.text);
                // $('#distance').text(`Distance: ${myroute.legs[0].distance.text}`);
                // $('#duration').text(`Duration: ${myroute.legs[0].duration.text}`);
            }



            //GET ALL THE USER FORM FIREBASE DATABASE
            //----------------------------------------------------------------
            setInterval(() => {
                firebase.database().ref('MapUsers').once('value', (snapshot) => {
                    reloadMarkers();
                    const data = snapshot.val();
                    for (const key in data) {
                        if (data.hasOwnProperty(key)) {
                            const element = data[key];
                            // console.log(element)
                            if (element.position != undefined) {
                                setMarker(element, key);
                            }

                        }
                    }
                });
            }, 5000);



            //ADDING MARKER AND INFO
            //---------------------------------------------------
            var selectedUserPosition;

            function setMarker(element, key) {

                var marker = new google.maps.Marker({
                    map: map,
                    position: {
                        lat: parseFloat(element.position.latitude),
                        lng: parseFloat(element.position.longitude)
                    },
                    icon: {
                        path: google.maps.SymbolPath.CIRCLE,
                        fillColor: element.connections != undefined && element.onlineStatus && element.onlineStatus != "false" ? "#0000ffe0" : "#ff0000",
                        fillOpacity: 0.8,
                        scale: 15,
                        strokeColor: "#ffffff",
                        strokeWeight: 1.5,
                    },
                });

                markers.push(marker);

                // adding userInfo
                var infowindow = new google.maps.InfoWindow({
                    maxWidth: 300,
                    infoBoxClearance: new google.maps.Size(1, 1),
                    disableAutoPan: false,
                    content: `
                <div style="font-size: 15px;">
                    <img height="50" src="${element.userInfo && element.userInfo.photoURL ? element.userInfo.photoURL : "../images/user.png"}" />
                    <span>${element.userInfo && element.userInfo.fullName ? element.userInfo.fullName : "Unknown Name"}</span>
                    
                    <br />
                    <br />
                    latitude: ${element.position.latitude} <br />
                    longitude: ${element.position.longitude} <br />
                    accuracy: ${element.position.accuracy} <br />
                    Elevation: ${element.position.elevation} meters <br />
                    speed: ${element.position.speed ? element.position.speed : 0} <br />
                    lastOnline: ${element.lastOnline ? Date(element.lastOnline).toString() : null} <br />
                    <br />
                    <button id="NavigatToCurrentUser">Navigation to me</button>
                </div>`
                });
                // infowindow.open(map, marker)
                google.maps.event.addListener(marker, 'click', function () {
                    selectedUserPosition = new google.maps.LatLng(element.position.latitude, element.position.longitude);
                    infowindow.open(map, marker);
                });


            }
            //RELOAD THE MARKERS
            function reloadMarkers() {
                for (var i = 0; i < markers.length; i++) {
                    markers[i].setMap(null);
                }
                markers = [];
            }


            // mapPanel
            //---------------------------------------
            const mapPanel = document.createElement("div");
            mapPanel.setAttribute('id', 'panelController');

            //distance TEXT
            //---------------------------------------
            const distance = document.createElement("i");
            distance.setAttribute('id', 'summaryabCollaps');
            distance.setAttribute('class', 'fa fa-minus-square-o');
            mapPanel.appendChild(distance);

            //CLEAR BUTTON
            //---------------------------------------
            const buttton = document.createElement("i");
            buttton.setAttribute('id', 'clearDiraction');
            buttton.setAttribute('class', 'fa fa-times');
            mapPanel.appendChild(buttton);


            document.getElementById('summaryab').appendChild(mapPanel)


            // DISPLAY ROUTER 
            // & CLEAR ROUTER 
            //-------------------------------------------------------
            let markersSearch = [];

            $(document).on('click', '#NavigatToCurrentUser', function () {
                displayRoute(selectedUserPosition);
                markersSearch.forEach((marker) => {
                    marker.setMap(null);
                });

                $('#floating-panel').show();
            });

            $(document).on('click', '#clearDiraction', function () {
                $('#summaryab').hide();
                $('#floating-panel').hide();
                directionsRenderer.set('directions', null);
            });

            document.getElementById("mode").addEventListener("change", () => {
                const selectedMode = document.getElementById("mode").value;
                displayRoute(selectedUserPosition, selectedMode);
            });

            //colapse summary
            $(document).on('click', '#summaryabCollaps', function () {
                var rightPanel = $('#right-panel');
                if (rightPanel.css('height') != '400px') {
                    rightPanel.css('height', '400px')
                    $('#summaryabCollaps').addClass('fa-minus-square-o')
                    $('#summaryabCollaps').removeClass('fa-plus-square-o')
                } else {
                    rightPanel.css('height', '80px')
                    $('#summaryabCollaps').removeClass('fa-minus-square-o')
                    $('#summaryabCollaps').addClass('fa-plus-square-o')
                }
            });

            $('.InfoIcon').on('click', function () {
                $('#currentInfoSection').show('slow');
            });
            $('.IconCancel').on('click', function () {
                $('#currentInfoSection').hide('slow');
            });

            $('#searchIcon').on('click', function () {
                $('#pac-input').show('slow');
                $('#searchIcon').hide('slow');
            });

            google.maps.event.addListener(map, 'click', function (event) {
                $('#pac-input').hide('slow');
                $('#searchIcon').show('slow');
            });



            //SEARCH LOCATION 
            //---------------------------------------------------------
            // Create the search box and link it to the UI element.
            const input = document.getElementById("pac-input");
            const searchBox = new google.maps.places.SearchBox(input);
            map.controls[google.maps.ControlPosition.TOP_CENTER].push(input);
            // Bias the SearchBox results towards current map's viewport.
            map.addListener("bounds_changed", () => {
                searchBox.setBounds(map.getBounds());
            });

            // Listen for the event fired when the user selects a prediction and retrieve
            // more details for that place.
            searchBox.addListener("places_changed", () => {
                const places = searchBox.getPlaces();

                if (places.length == 0) {
                    return;
                }
                // Clear out the old markersSearch.
                markersSearch.forEach((marker) => {
                    marker.setMap(null);
                });
                markersSearch = [];
                // For each place, get the icon, name and location.
                const bounds = new google.maps.LatLngBounds();
                places.forEach((place) => {
                    if (!place.geometry) {
                        console.log("Returned place contains no geometry");
                        return;
                    }
                    const icon = {
                        url: place.icon,
                        size: new google.maps.Size(71, 71),
                        origin: new google.maps.Point(0, 0),
                        anchor: new google.maps.Point(17, 34),
                        scaledSize: new google.maps.Size(25, 25),
                    };

                    // Create a marker for each place.
                    var searchPlaceMarker = new google.maps.Marker({
                        map,
                        icon,
                        title: place.name,
                        position: place.geometry.location,
                    });
                    markersSearch.push(searchPlaceMarker);

                    // adding userInfo
                    var searchPlaceinfowindow = new google.maps.InfoWindow({
                        maxWidth: 300,
                        infoBoxClearance: new google.maps.Size(1, 1),
                        disableAutoPan: false,
                        content: `
                        <div style="font-size: 15px;">
                            <h3>navigate to this location</h3>
                            <button id="NavigatToCurrentUser">Navigation to me</button>
                        </div>
                    `
                    });
                    new google.maps.event.addListener(searchPlaceMarker, 'click', function (e) {
                        selectedUserPosition = new google.maps.LatLng(searchPlaceMarker.getPosition().lat(), searchPlaceMarker.getPosition().lng());
                        searchPlaceinfowindow.open(map, searchPlaceMarker);
                    });



                    if (place.geometry.viewport) {
                        // Only geocodes have viewport.
                        bounds.union(place.geometry.viewport);
                    } else {
                        bounds.extend(place.geometry.location);
                    }
                });
                map.fitBounds(bounds);
            });





            // geocoder.geocode({ 'latLng': latlng }, function (results, status) {
            //     if (status == google.maps.GeocoderStatus.OK) {
            //         if (results[1]) {
            //             for (var i = 0; i < results[0].address_components.length; i++) {
            //                 for (var b = 0; b < results[0].address_components[i].types.length; b++) {
            //                     if (results[0].address_components[i].types[b] == "administrative_area_level_1") {
            //                         city = results[0].address_components[i];
            //                         break;
            //                     }
            //                 }
            //             }
            //             $('.cityName').html(city.long_name);
            //             $('.countryName').html(results[7].formatted_address);
            //         } else {
            //             alert("No results found");
            //         }
            //     } else {
            //         alert("Geocoder failed due to: " + status);
            //     }
            // });


            // google.maps.event.addListener(map, 'click', function (event) {
            // placeMarker(event.latLng)
            // });

            var longpress = false;
            google.maps.event.addListener(map, 'click', function (event) {
                (longpress) ? placeMarker(event.latLng): console.log("Short Press");
            });
            google.maps.event.addListener(map, 'mousedown', function (event) {
                start = new Date().getTime();
            });
            google.maps.event.addListener(map, 'mouseup', function (event) {
                end = new Date().getTime();
                longpress = (end - start < 500) ? false : true;
            });



            var clickMarkerList = []

            function placeMarker(location) {

                clickMarkerList.forEach((marker) => {
                    marker.setMap(null);
                });

                var clickMarker = new google.maps.Marker({
                    position: location,
                    map: map,
                    draggable: true

                });
                clickMarkerList.push(clickMarker);

                // adding userInfo
                var clickMarkerInfowindow = new google.maps.InfoWindow({
                    maxWidth: 300,
                    infoBoxClearance: new google.maps.Size(1, 1),
                    disableAutoPan: false,
                    content: `
                    <div style="font-size: 15px;">
                        <h3>navigate to this location</h3>
                        <button id="NavigatToCurrentUser">Navigation to me</button>
                    </div>
                `
                });
                new google.maps.event.addListener(clickMarker, 'click', function (e) {
                    selectedUserPosition = new google.maps.LatLng(clickMarker.getPosition().lat(), clickMarker.getPosition().lng());
                    clickMarkerInfowindow.open(map, clickMarker);
                });
            }



        }

    }
});