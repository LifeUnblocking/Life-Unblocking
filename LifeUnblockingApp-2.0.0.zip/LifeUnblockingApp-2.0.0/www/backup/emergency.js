document.addEventListener("deviceready", onDeviceReady, false);
// $(document).ready(onDeviceReady)

function onDeviceReady() {

    //-----------------------------------------
    //            return emergencyCall
    //-----------------------------------------
    $(document).delegate("#emergencyCall", "pageinit", function () {

        cordova.plugins.diagnostic.requestLocationAuthorization(function (status) {
            switch (status) {
                case cordova.plugins.diagnostic.permissionStatus.NOT_REQUESTED:
                    console.log("Permission not requested");
                    break;
                case cordova.plugins.diagnostic.permissionStatus.GRANTED:
                    console.log("Permission granted");
                    UpdateUserLocationTofirebase();
                    break;
                case cordova.plugins.diagnostic.permissionStatus.DENIED:
                    console.log("Permission denied");
                    $.mobile.navigate("./parmition.html");

                    break;
                case cordova.plugins.diagnostic.permissionStatus.DENIED_ALWAYS:
                    console.log("Permission permanently denied");
                    $.mobile.navigate("./parmition.html");
                    break;
            }
        }, function (error) {
            console.error(error);
        });



    });


    //-----------------------------------------
    //            return emergencyCall
    //-----------------------------------------
    $(document).delegate("#emergencySignal", "pageinit", function () {

        cordova.plugins.diagnostic.requestLocationAuthorization(function (status) {
            switch (status) {
                case cordova.plugins.diagnostic.permissionStatus.NOT_REQUESTED:
                    console.log("Permission not requested");
                    break;
                case cordova.plugins.diagnostic.permissionStatus.GRANTED:
                    console.log("Permission granted");
                    UpdateUserLocationTofirebase();
                    break;
                case cordova.plugins.diagnostic.permissionStatus.DENIED:
                    console.log("Permission denied");
                    $.mobile.navigate("./parmition.html");

                    break;
                case cordova.plugins.diagnostic.permissionStatus.DENIED_ALWAYS:
                    console.log("Permission permanently denied");
                    $.mobile.navigate("./parmition.html");
                    break;
            }
        }, function (error) {
            console.error(error);
        });


       
        $('#SignalOnButton').on('click', function () {
            window.plugins.flashlight.available(function (isAvailable) {
                if (isAvailable) {

                    var lightOn = true;
                    var shortTtme = 200;
                    var longTime = 500; 

                    const delay = ms => new Promise(res => setTimeout(res, ms));
                    const yourFunction = async () => {

                        if(lightOn != true) return false;
                        window.plugins.flashlight.switchOn();
                        await delay(shortTtme);
                        window.plugins.flashlight.switchOff();
                        await delay(shortTtme);

                        if(lightOn != true) return false;
                        window.plugins.flashlight.switchOn();
                        await delay(shortTtme);
                        window.plugins.flashlight.switchOff();
                        await delay(shortTtme);

                        if(lightOn != true) return false;
                        window.plugins.flashlight.switchOn();
                        await delay(shortTtme);
                        window.plugins.flashlight.switchOff();
                        await delay(longTime);

                        //solow
                        if(lightOn != true) return false ;
                        window.plugins.flashlight.switchOn();
                        await delay(longTime);
                        window.plugins.flashlight.switchOff();
                        await delay(longTime);

                        if(lightOn != true) return false ;
                        window.plugins.flashlight.switchOn();
                        await delay(longTime);
                        window.plugins.flashlight.switchOff();
                        await delay(longTime);

                        if(lightOn != true) return false ;
                        window.plugins.flashlight.switchOn();
                        await delay(longTime);
                        window.plugins.flashlight.switchOff();
                        await delay(shortTtme);

                        yourFunction()
                    };

                    yourFunction()

                    $('#SignalOffButton').on('click', function () {
                        lightOn = false;
                        window.plugins.flashlight.switchOff();
                    });
                } else {
                    alert("Flashlight not available on this device");
                }
            });
        });

        


    });

    function UpdateUserLocationTofirebase() {
        if (navigator.geolocation) {
            var watchID = navigator.geolocation.watchPosition(function (position) {

                $('#currentCoordinates .Lat').text(position.coords.latitude);
                $('#currentCoordinates .lang').text(position.coords.longitude);
                $('#currentCoordinates .speed').text(position.coords.speed ? Number(position.coords.speed).toFixed(2) + " km/h" : 0 + " km/h");

                //-------------------------------------------------------
                //Elevation Service Connection
                //-------------------------------------------------------
                const elevator = new google.maps.ElevationService();
                const ellatnag = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
                elevator.getElevationForLocations({
                        locations: [ellatnag],
                    },
                    (results, status) => {
                        if (status === "OK") {
                            // Retrieve the first result
                            if (results[0]) {
                                $('#currentCoordinates .elevation').text(Number(results[0].elevation).toFixed(2) + " meters");

                            }
                        } else {
                            console.log("Elevation service failed due to: " + status);
                        }
                    }
                );


            }, function (error) {
                console.log('code: ' + error.code + '\n' +
                    'message: ' + error.message + '\n');
            }, {
                maximumAge: 500000,
                timeout: 6000,
                enableHighAccuracy: true
            });
        } else {
            alert('geolocation not suported');
        }
    }
}