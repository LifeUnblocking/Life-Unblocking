var language = [
    {
        name: 'english',
        code: 'en',
    },
    {
        name: 'spanish',
        code: 'sp',
    },
    {
        name: 'French',
        code: 'fr',
    },
    {
        name: 'Italian',
        code: 'it',
    },
    {
        name: 'Portuguese',
        code: 'po',
    },
    {
        name: 'Chinese',
        code: 'ch',
    },
]


$(document).delegate("#languagePage", "pageinit", function () {

    //Rander Language List
    randerLanguageList()

    $(document).on('click', '.languageItem', function () {

        //save language
        window.localStorage.setItem('language', JSON.stringify({
            name: $(this).find('.name').val(),
            code: $(this).find('.code').val(),
        }));

        //Rander Language List
        randerLanguageList();

    });
});


//change language on register screen
$(document).delegate("#registerPage", "pagecreate", function () {
    var GetSavedLanguageForRegister = JSON.parse(window.localStorage.getItem('language'));
    if (GetSavedLanguageForRegister) {
        $('.cheangeLanguae img').attr('src', `language/flags/${GetSavedLanguageForRegister.code}.png`)
        $('.cheangeLanguae span').text(GetSavedLanguageForRegister.name)
        $('.cheangeLanguae span').attr('data-translate',GetSavedLanguageForRegister.code)
    } else {
        $('.cheangeLanguae img').attr('src', `language/flags/en.png`)
        $('.cheangeLanguae span').text('english');
    }
})


//translate language on evry screen
$(document).on("pagecreate", function () {
    var getSavedLanguage = window.localStorage.getItem('language');
    if (getSavedLanguage) {
        var savedLanguage = JSON.parse(getSavedLanguage);
        $("[data-translate]").jqTranslate('lang', {
            asyncLangLoad: false,
            forceLang: savedLanguage.code,
            path: 'language/translate'
        });
    } else {
        $("[data-translate]").jqTranslate('lang', {
            asyncLangLoad: false,
            defaultLang: 'en',
            path: 'language/translate'
        });
    }
});



function randerLanguageList() {
    $('.language-section ul').empty();
    var savedLanguage = JSON.parse(window.localStorage.getItem('language'));
    for (const iterator of language) {

        var selectIcon;
        if (savedLanguage) {
            if (savedLanguage.name == iterator.name) {
                selectIcon = '<i class="fa fa-check-square-o" aria-hidden="true"></i>'
            } else {
                selectIcon = '<i class="fa fa-square-o" aria-hidden="true"></i>'
            }
        } else if (iterator.name == "english") {
            selectIcon = '<i class="fa fa-check-square-o" aria-hidden="true"></i>'
        } else {
            selectIcon = '<i class="fa fa-square-o" aria-hidden="true"></i>'
        }


        $('.language-section ul').append(`<li class="languageItem">
        <input type="hidden" class="name" value="${iterator.name}">
        <input type="hidden" class="code" value="${iterator.code}">
            <img src="./language/flags/${iterator.code}.png">
            <span data-translate="${iterator.code}">${iterator.name}</span>
            ${selectIcon}
        </li>`);


    }

    //change language
    if(savedLanguage){
        $("[data-translate]").jqTranslate('lang', {
            asyncLangLoad: false,
            forceLang: savedLanguage.code,
            path: 'language/translate'
        });
    }
    


}